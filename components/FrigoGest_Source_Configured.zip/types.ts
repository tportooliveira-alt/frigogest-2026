
// Data Models based on the Prompt's SQL Schema

export interface Client {
  id_ferro: string; // PK: ID_FERRO
  nome_social: string;
  whatsapp: string;
  limite_credito: number;
  saldo_devedor: number;
  endereco?: string;
  bairro?: string;
  cidade?: string;
  observacoes?: string;
}

export interface Batch {
  id_lote: string; // PK
  fornecedor: string;
  data_recebimento: string; // ISO Date
  peso_total_romaneio: number;
  valor_compra_total: number;
  frete: number;
  gastos_extras: number;
  custo_real_kg: number;
  url_romaneio?: string; // Novo campo para imagem/PDF do romaneio original
}

export enum StockType {
  INTEIRO = 1,
  BANDA_A = 2,
  BANDA_B = 3,
}

export interface StockItem {
  id_completo: string; // PK: LOTE-SEQ-TIPO
  id_lote: string; // FK
  sequencia: number;
  tipo: StockType;
  peso_entrada: number;
  peso_animal_entrada?: number; // Soma de A+B ou Integral
  status: 'DISPONIVEL' | 'VENDIDO';
  data_entrada: string;
}

export type PaymentMethod = 'DINHEIRO' | 'PIX' | 'CHEQUE' | 'BOLETO' | 'TRANSFERENCIA' | 'OUTROS';

export interface Sale {
  id_venda: string;
  id_cliente: string;
  nome_cliente?: string; // Persistência do nome para histórico
  id_completo: string;
  peso_real_saida: number;
  preco_venda_kg: number;
  data_venda: string;
  quebra_kg: number;
  lucro_liquido_unitario: number;
  custo_extras_total: number;
  prazo_dias: number;
  data_vencimento: string;
  forma_pagamento: PaymentMethod;
  status_pagamento: 'PENDENTE' | 'PAGO';
}

export interface Transaction {
  id: string;
  data: string;
  descricao: string;
  tipo: 'ENTRADA' | 'SAIDA';
  categoria: 'VENDA' | 'COMPRA_GADO' | 'OPERACIONAL' | 'ADMINISTRATIVO' | 'OUTROS';
  valor: number;
  referencia_id?: string;
  metodo_pagamento?: PaymentMethod;
}

export interface AppState {
  clients: Client[];
  batches: Batch[];
  stock: StockItem[];
  sales: Sale[];
  transactions: Transaction[];
}
