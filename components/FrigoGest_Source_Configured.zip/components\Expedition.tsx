import React, { useState, useMemo } from 'react';
import { StockItem, Client, Sale } from '../types';
import { Search, ShoppingCart, User, CheckCircle, X, Calendar, ClipboardList, Trash2, ArrowLeft, Zap } from 'lucide-react';
import { formatWeight, formatCurrency } from '../utils/helpers';

interface ExpeditionProps {
  stock: StockItem[];
  clients: Client[];
  onConfirmSale: (saleData: any) => void;
  onBack: () => void;
  salesHistory: Sale[];
}

// Cores para agrupar carcaças (bandas da mesma sequência)
const CARCASS_COLORS = [
  { bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-700', selected: 'bg-blue-500', hover: 'hover:bg-blue-100' },
  { bg: 'bg-emerald-50', border: 'border-emerald-200', text: 'text-emerald-700', selected: 'bg-emerald-500', hover: 'hover:bg-emerald-100' },
  { bg: 'bg-purple-50', border: 'border-purple-200', text: 'text-purple-700', selected: 'bg-purple-500', hover: 'hover:bg-purple-100' },
  { bg: 'bg-amber-50', border: 'border-amber-200', text: 'text-amber-700', selected: 'bg-amber-500', hover: 'hover:bg-amber-100' },
  { bg: 'bg-rose-50', border: 'border-rose-200', text: 'text-rose-700', selected: 'bg-rose-500', hover: 'hover:bg-rose-100' },
  { bg: 'bg-indigo-50', border: 'border-indigo-200', text: 'text-indigo-700', selected: 'bg-indigo-500', hover: 'hover:bg-indigo-100' },
  { bg: 'bg-teal-50', border: 'border-teal-200', text: 'text-teal-700', selected: 'bg-teal-500', hover: 'hover:bg-teal-100' },
  { bg: 'bg-pink-50', border: 'border-pink-200', text: 'text-pink-700', selected: 'bg-pink-500', hover: 'hover:bg-pink-100' },
];

const Expedition: React.FC<ExpeditionProps> = ({ stock, clients, onConfirmSale, onBack, salesHistory }) => {
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [selectedItems, setSelectedItems] = useState<StockItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showHistory, setShowHistory] = useState(false);
  const [showCart, setShowCart] = useState(false);

  const availableStock = useMemo(() => stock.filter(item => item.status === 'DISPONIVEL'), [stock]);

  // Agrupar por lote e sequência
  const groupedStock = useMemo(() => {
    const filtered = availableStock.filter(item =>
      item.id_completo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.id_lote.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const groups = new Map<string, StockItem[]>();
    filtered.forEach(item => {
      const key = `${item.id_lote}-${item.sequencia}`;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(item);
    });

    return Array.from(groups.entries()).map(([key, items], index) => ({
      key,
      items,
      color: CARCASS_COLORS[index % CARCASS_COLORS.length],
      lote: items[0].id_lote,
      sequencia: items[0].sequencia,
      totalWeight: items.reduce((acc, i) => acc + i.peso_entrada, 0),
    }));
  }, [availableStock, searchTerm]);

  const [itemWeights, setItemWeights] = useState<Record<string, number>>({});

  const getTotalWeight = () => {
    return selectedItems.reduce((acc, item) => {
      const customWeight = itemWeights[item.id_completo];
      return acc + (customWeight !== undefined ? customWeight : item.peso_entrada);
    }, 0);
  };

  const totalWeight = getTotalWeight();
  const [pricePerKg, setPricePerKg] = useState<number>(0);
  const [extrasCost, setExtrasCost] = useState<number>(0);
  const totalValue = totalWeight * pricePerKg;

  const handleWeightChange = (itemId: string, newWeight: number) => {
    setItemWeights(prev => ({ ...prev, [itemId]: newWeight }));
  };

  const handleToggleItem = (item: StockItem) => {
    if (selectedItems.find(i => i.id_completo === item.id_completo)) {
      setSelectedItems(prev => prev.filter(i => i.id_completo !== item.id_completo));
      // Remove peso customizado ao remover item
      setItemWeights(prev => {
        const newWeights = { ...prev };
        delete newWeights[item.id_completo];
        return newWeights;
      });
    } else {
      setSelectedItems(prev => [...prev, item]);
      // Inicializa com peso de entrada
      setItemWeights(prev => ({ ...prev, [item.id_completo]: item.peso_entrada }));
    }
  };

  const handleToggleGroup = (items: StockItem[]) => {
    const allSelected = items.every(item => selectedItems.some(i => i.id_completo === item.id_completo));
    if (allSelected) {
      setSelectedItems(prev => prev.filter(i => !items.some(item => item.id_completo === i.id_completo)));
    } else {
      const newItems = items.filter(item => !selectedItems.some(i => i.id_completo === item.id_completo));
      setSelectedItems(prev => [...prev, ...newItems]);
    }
  };

  const handleConfirm = () => {
    if (!selectedClient || selectedItems.length === 0 || pricePerKg <= 0) {
      alert("⚠️ Preencha todos os dados da venda!");
      return;
    }
    onConfirmSale({ client: selectedClient, items: selectedItems, pricePerKg, extrasCost });
    setSelectedClient(null); setSelectedItems([]); setPricePerKg(0); setExtrasCost(0);
  };

  if (showHistory) {
    return (
      <div className="p-4 md:p-6 min-h-screen bg-gray-50 text-gray-900 animate-fade-in pb-20 font-sans">
        <button onClick={() => setShowHistory(false)} className="text-gray-600 hover:text-blue-600 flex items-center gap-2 mb-6 text-sm font-bold transition-colors">
          <ArrowLeft size={16} /> Voltar
        </button>
        <div className="flex items-center gap-4 mb-8">
          <div className="bg-white p-3 rounded-xl border border-gray-200 shadow-sm">
            <ClipboardList size={22} className="text-blue-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Histórico de Vendas</h2>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-gray-600">
              <thead className="bg-gray-50 text-gray-700 font-bold text-xs border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4">Data</th>
                  <th className="px-6 py-4">Cliente</th>
                  <th className="px-6 py-4">ID</th>
                  <th className="px-6 py-4 text-right">Peso</th>
                  <th className="px-6 py-4 text-right">Valor</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {salesHistory.slice(0, 50).map((sale, idx) => (
                  <tr key={idx} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 font-mono text-xs">{new Date(sale.data_venda).toLocaleDateString()}</td>
                    <td className="px-6 py-4 text-gray-900 font-semibold">{sale.nome_cliente || 'BALCÃO'}</td>
                    <td className="px-6 py-4 font-mono text-gray-500 text-xs">{sale.id_completo}</td>
                    <td className="px-6 py-4 text-right font-mono text-blue-600 font-semibold">{formatWeight(sale.peso_real_saida)}</td>
                    <td className="px-6 py-4 text-right font-mono font-bold text-emerald-600">{formatCurrency(sale.peso_real_saida * sale.preco_venda_kg)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50 text-gray-900 overflow-hidden animate-fade-in font-sans">
      {/* HEADER */}
      <div className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 shrink-0 shadow-sm z-30">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-white bg-blue-600 hover:bg-blue-700 p-3 rounded-xl border border-blue-700 transition-all hover:shadow-md active:scale-95 flex items-center gap-2">
            <ArrowLeft size={20} />
            <span className="font-bold text-sm">Voltar</span>
          </button>
          <div className="h-6 w-[1px] bg-gray-200"></div>
          <div>
            <h1 className="text-sm font-bold text-gray-900 flex items-center gap-2">
              <ShoppingCart size={16} className="text-blue-600" /> Vendas
            </h1>
          </div>
        </div>
        <button onClick={() => setShowHistory(true)} className="text-xs font-bold text-gray-600 hover:text-blue-600 flex items-center gap-2 px-3 py-2 rounded-lg bg-gray-50 border border-gray-200 transition-all hover:shadow-sm">
          <ClipboardList size={14} /> <span className="hidden sm:inline">Histórico</span>
        </button>
      </div>

      {/* MAIN CONTENT */}
      <div className="flex-1 flex flex-col overflow-hidden relative md:mr-80">
        {/* CLIENT SELECTOR */}
        <div className="p-3 md:p-4 border-b border-gray-200 bg-white z-20">
          <div className="max-w-6xl mx-auto w-full">
            <label className="text-xs font-bold text-gray-600 mb-2 block">Cliente</label>
            <select
              className="w-full bg-gray-50 border border-gray-300 rounded-xl px-3 py-3 text-gray-900 outline-none focus:ring-2 focus:ring-blue-500 transition-all font-semibold text-sm"
              value={selectedClient ? JSON.stringify(selectedClient) : ""}
              onChange={(e) => {
                if (e.target.value) setSelectedClient(JSON.parse(e.target.value));
                else setSelectedClient(null);
              }}
            >
              <option value="">Selecionar cliente...</option>
              {clients.map(client => (
                <option key={client.id_ferro} value={JSON.stringify(client)}>
                  {client.nome_social} / {client.cidade || 'N/A'}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* SEARCH BAR */}
        <div className="p-3 md:p-4 border-b border-gray-200 bg-white sticky top-0 z-20">
          <div className="max-w-6xl mx-auto w-full flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input
                type="text"
                placeholder="Buscar por lote ou ID..."
                className="w-full bg-gray-50 border border-gray-300 rounded-xl pl-10 pr-4 py-3 text-sm text-gray-900 font-medium focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder-gray-400"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* STOCK GRID - COMPACTO E AGRUPADO */}
        <div className="flex-1 overflow-y-auto p-3 md:p-4 pb-32 md:pb-4 bg-gray-100">
          <div className="max-w-6xl mx-auto">
            {groupedStock.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 opacity-30">
                <Zap size={48} className="text-gray-400 mb-4" />
                <p className="text-sm font-semibold text-gray-500">Nenhum item disponível</p>
              </div>
            ) : (
              <div className="space-y-3">
                {groupedStock.map(group => {
                  const allSelected = group.items.every(item => selectedItems.some(i => i.id_completo === item.id_completo));
                  const someSelected = group.items.some(item => selectedItems.some(i => i.id_completo === item.id_completo));

                  return (
                    <div key={group.key} className={`${group.color.bg} border-2 ${allSelected ? group.color.selected.replace('bg-', 'border-') : group.color.border} rounded-xl p-3 transition-all shadow-sm hover:shadow-md`}>
                      {/* HEADER DO GRUPO - Carcaça Completa */}
                      <div className="flex items-center justify-between mb-2 pb-2 border-b border-gray-200">
                        <div className="flex items-center gap-3">
                          <div className={`px-2 py-1 rounded-lg ${group.color.bg} border ${group.color.border}`}>
                            <span className={`text-xs font-black ${group.color.text}`}>
                              #{group.sequencia}
                            </span>
                          </div>
                          <div>
                            <p className="text-xs font-bold text-gray-700">Lote: {group.lote}</p>
                            <p className="text-xs text-gray-500 font-medium">{formatWeight(group.totalWeight)}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => handleToggleGroup(group.items)}
                          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${allSelected
                            ? `${group.color.selected} text-white shadow-md`
                            : `bg-white border-2 ${group.color.border} ${group.color.text} hover:shadow-sm`
                            }`}
                        >
                          {allSelected ? '✓ Selecionado' : someSelected ? 'Selecionar Tudo' : 'Selecionar Carcaça'}
                        </button>
                      </div>

                      {/* BANDAS - COMPACTAS */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
                        {group.items.map(item => {
                          const isSelected = selectedItems.some(i => i.id_completo === item.id_completo);
                          return (
                            <button
                              key={item.id_completo}
                              onClick={() => handleToggleItem(item)}
                              className={`relative p-2 rounded-lg border-2 cursor-pointer transition-all text-left ${isSelected
                                ? `${group.color.selected} border-transparent text-white shadow-md scale-105`
                                : `bg-white ${group.color.border} ${group.color.text} ${group.color.hover}`
                                }`}
                            >
                              <div className="flex flex-col">
                                <span className="text-[10px] font-bold opacity-70 uppercase">{item.tipo}</span>
                                <span className="text-sm font-black">{formatWeight(item.peso_entrada)}</span>
                                <span className="text-[9px] font-mono opacity-60 truncate">{item.id_completo.split('-').pop()}</span>
                              </div>
                              {isSelected && (
                                <div className="absolute top-1 right-1">
                                  <CheckCircle size={12} className="text-white" />
                                </div>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* FLOATING CART BUTTON (Mobile) */}
      <button
        onClick={() => setShowCart(true)}
        className={`md:hidden fixed bottom-6 right-6 z-40 w-16 h-16 rounded-full shadow-2xl flex items-center justify-center transition-all active:scale-95 ${selectedItems.length > 0 ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-300'}`}
      >
        <div className="relative">
          <ShoppingCart size={24} className="text-white" />
          {selectedItems.length > 0 && (
            <span className="absolute -top-2 -right-2 bg-emerald-500 text-white text-[10px] font-black rounded-full w-5 h-5 flex items-center justify-center">
              {selectedItems.length}
            </span>
          )}
        </div>
      </button>

      {/* CART SIDEBAR (Desktop) */}
      <div className="hidden md:flex w-80 bg-white border-l border-gray-200 flex-col shadow-lg z-30 fixed right-0 top-14 bottom-0">
        <div className="p-4 border-b border-gray-200 bg-gray-50">
          <h2 className="text-sm font-bold text-gray-900 flex items-center gap-2">
            <ShoppingCart size={16} className="text-blue-600" /> Carrinho
          </h2>
          <p className="text-gray-600 text-xs font-semibold mt-1">
            {selectedItems.length} itens
          </p>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {selectedItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-400 gap-3 opacity-50 px-6 text-center">
              <ShoppingCart size={32} />
              <p className="text-xs font-semibold">Carrinho vazio</p>
            </div>
          ) : (
            selectedItems.map((item, idx) => {
              const currentWeight = itemWeights[item.id_completo] !== undefined ? itemWeights[item.id_completo] : item.peso_entrada;
              return (
                <div key={idx} className="bg-gray-50 border border-gray-200 p-2 rounded-lg hover:shadow-sm transition-all space-y-2">
                  <div className="flex justify-between items-start">
                    <div className="flex-1 min-w-0">
                      <span className="font-mono text-gray-900 font-bold text-xs block truncate">{item.id_completo}</span>
                      <span className="text-[10px] text-gray-500 font-semibold">#{item.sequencia} • {item.tipo}</span>
                    </div>
                    <button onClick={() => handleToggleItem(item)} className="text-gray-400 hover:text-red-500 p-1"><X size={14} /></button>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1">
                      <label className="text-[9px] text-gray-500 font-bold block mb-1">Peso Saída (KG)</label>
                      <input
                        type="number"
                        step="0.01"
                        inputMode="decimal"
                        className="w-full bg-white border border-gray-300 rounded px-2 py-1 text-gray-900 font-mono text-xs font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                        value={currentWeight}
                        onChange={e => handleWeightChange(item.id_completo, parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div className="text-right">
                      <span className="text-[9px] text-gray-400 font-bold block mb-1">Entrada</span>
                      <span className="font-mono text-gray-500 text-[10px] bg-gray-100 px-2 py-1 rounded">{formatWeight(item.peso_entrada)}</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div className="p-4 bg-gray-50 border-t border-gray-200 space-y-3">
          <div>
            <label className="text-xs text-gray-600 font-bold mb-1 block">Preço (R$/KG)</label>
            <input
              type="number"
              step="0.01"
              inputMode="decimal"
              className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-gray-900 font-mono text-center font-bold focus:ring-2 focus:ring-blue-500 outline-none text-xl"
              value={pricePerKg || ''}
              onChange={e => setPricePerKg(parseFloat(e.target.value))}
              placeholder="0.00"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-[10px] text-gray-600 font-bold">Extras (R$)</span>
              <input type="number" step="0.01" inputMode="decimal" className="w-full bg-white border border-gray-300 rounded-lg px-2 py-1.5 text-gray-900 font-mono text-xs text-right focus:ring-2 focus:ring-blue-500 outline-none" value={extrasCost || ''} onChange={e => setExtrasCost(parseFloat(e.target.value))} placeholder="0.00" />
            </div>
            <div className="text-right flex flex-col justify-end">
              <span className="text-[10px] text-gray-600 font-bold">Peso Total</span>
              <span className="font-mono text-gray-900 font-bold text-sm bg-gray-100 border border-gray-200 rounded-lg px-2 py-1.5">{formatWeight(totalWeight)}</span>
            </div>
          </div>

          <div className="pt-3 border-t border-gray-200">
            <div className="flex justify-between items-center mb-3">
              <span className="text-xs font-bold text-gray-600">Total:</span>
              <span className="font-mono text-2xl font-black text-emerald-600">{formatCurrency(totalValue)}</span>
            </div>
            <button
              onClick={handleConfirm}
              disabled={selectedItems.length === 0 || !selectedClient || pricePerKg <= 0}
              className={`w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md ${selectedItems.length > 0 && selectedClient && pricePerKg > 0
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
            >
              <CheckCircle size={18} /> CONFIRMAR VENDA
            </button>
          </div>
        </div>
      </div>

      {/* MOBILE CART MODAL */}
      {showCart && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl border-t border-gray-200 shadow-2xl max-h-[85vh] flex flex-col">
            <div className="p-4 border-b border-gray-200 flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-gray-900 flex items-center gap-2">
                  <ShoppingCart size={16} className="text-blue-600" /> Carrinho
                </h2>
                <p className="text-gray-600 text-xs font-semibold mt-1">
                  {selectedItems.length} itens
                </p>
              </div>
              <button onClick={() => setShowCart(false)} className="text-gray-400 hover:text-gray-900 p-2 bg-gray-50 rounded-full">
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {selectedItems.map((item, idx) => {
                const currentWeight = itemWeights[item.id_completo] !== undefined ? itemWeights[item.id_completo] : item.peso_entrada;
                return (
                  <div key={idx} className="bg-gray-50 border border-gray-200 p-3 rounded-xl space-y-2">
                    <div className="flex justify-between items-start">
                      <div className="flex-1 min-w-0">
                        <span className="font-mono text-gray-900 font-bold text-xs block truncate">{item.id_completo}</span>
                        <span className="text-[10px] text-gray-500 font-semibold">SEQ #{item.sequencia} • {item.tipo}</span>
                      </div>
                      <button onClick={() => handleToggleItem(item)} className="text-gray-400 hover:text-red-500 p-1.5 bg-white rounded-lg active:scale-95">
                        <Trash2 size={14} />
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1">
                        <label className="text-[9px] text-gray-500 font-bold block mb-1">Peso Saída (KG)</label>
                        <input
                          type="number"
                          step="0.01"
                          inputMode="decimal"
                          className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-gray-900 font-mono text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                          value={currentWeight}
                          onChange={e => handleWeightChange(item.id_completo, parseFloat(e.target.value) || 0)}
                        />
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-gray-400 font-bold block mb-1">Entrada</span>
                        <span className="font-mono text-gray-500 text-xs bg-gray-100 px-2 py-2 rounded">{formatWeight(item.peso_entrada)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-4 bg-gray-50 border-t border-gray-200 space-y-3">
              <div>
                <label className="text-xs text-gray-600 font-bold mb-1 block">Preço (R$/KG)</label>
                <input
                  type="number"
                  step="0.01"
                  inputMode="decimal"
                  className="w-full bg-white border border-gray-300 rounded-xl px-4 py-3 text-gray-900 font-mono text-center font-bold focus:ring-2 focus:ring-blue-500 outline-none text-xl"
                  value={pricePerKg || ''}
                  onChange={e => setPricePerKg(parseFloat(e.target.value))}
                  placeholder="0.00"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-[10px] text-gray-600 font-bold">Extras (R$)</span>
                  <input
                    type="number"
                    step="0.01"
                    inputMode="decimal"
                    className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-gray-900 font-mono text-xs text-right focus:ring-2 focus:ring-blue-500 outline-none"
                    value={extrasCost || ''}
                    onChange={e => setExtrasCost(parseFloat(e.target.value))}
                    placeholder="0.00"
                  />
                </div>
                <div className="text-right flex flex-col justify-end">
                  <span className="text-[10px] text-gray-600 font-bold">Peso Total</span>
                  <span className="font-mono text-gray-900 font-bold text-sm bg-gray-100 border border-gray-200 rounded-lg px-3 py-2">{formatWeight(totalWeight)}</span>
                </div>
              </div>

              <div className="pt-3 border-t border-gray-200">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-xs font-bold text-gray-600">Valor Total:</span>
                  <span className="font-mono text-2xl font-black text-emerald-600">{formatCurrency(totalValue)}</span>
                </div>
                <button
                  onClick={() => {
                    handleConfirm();
                    setShowCart(false);
                  }}
                  disabled={selectedItems.length === 0 || !selectedClient || pricePerKg <= 0}
                  className={`w-full py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg ${selectedItems.length > 0 && selectedClient && pricePerKg > 0
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    }`}
                >
                  <CheckCircle size={18} /> CONFIRMAR VENDA
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Expedition;
