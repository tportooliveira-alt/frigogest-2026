import { CURRENT_DATE } from '../constants';

export const calculateDaysInStock = (entryDate: string): number => {
  const start = new Date(entryDate);
  const current = new Date(CURRENT_DATE);
  const diffTime = Math.abs(current.getTime() - start.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

export const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
};

export const formatWeight = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value) + ' kg';
};

// Logic required by prompt for Cost Calculation
export const calculateRealCost = (
  purchaseTotal: number,
  freight: number,
  extras: number,
  totalWeight: number
): number => {
  if (totalWeight === 0) return 0;
  return (purchaseTotal + freight + extras) / totalWeight;
};

export const exportToCSV = (data: any[], filename: string) => {
  if (!data || !data.length) return;

  const separator = ';'; // Using semicolon for better Excel compatibility in Brazil/Europe
  const keys = Object.keys(data[0]);
  const csvContent =
    keys.join(separator) +
    '\n' +
    data.map(row => {
      return keys.map(k => {
        let cell = row[k] === null || row[k] === undefined ? '' : row[k];
        cell = cell instanceof Date
          ? cell.toLocaleString()
          : cell.toString().replace(/"/g, '""'); // Escape double quotes

        // Wrap in quotes if contains separator, newline or quotes
        if (cell.search(new RegExp(`("|${separator}|\n)`)) >= 0) {
          cell = `"${cell}"`;
        }
        return cell;
      }).join(separator);
    }).join('\n');

  // Add BOM for UTF-8 compatibility in Excel
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};