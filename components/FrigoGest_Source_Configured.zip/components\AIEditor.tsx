
import React, { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { ArrowLeft, Upload, Wand2, Download, Image as ImageIcon, Loader2, Sparkles, AlertCircle, Info, Palette } from 'lucide-react';

interface AIEditorProps {
    onBack: () => void;
}

const AIEditor: React.FC<AIEditorProps> = ({ onBack }) => {
    const [selectedImage, setSelectedImage] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [prompt, setPrompt] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [mode, setMode] = useState<'edit' | 'logo'>('edit');
    const fileInputRef = useRef<HTMLInputElement>(null);

    const quickPromptsEdit = [
        "Remover o fundo e deixar branco",
        "Melhorar a iluminação do produto",
        "Adicionar etiqueta de 'Oferta Especial'",
        "Colocar sobre uma mesa de madeira rústica"
    ];

    const quickPromptsLogo = [
        "Logo minimalista de um touro, luxo, dourado e preto",
        "Logo moderno para frigorífico, cores vermelha e branca, estilo flat",
        "Logomarca rústica com desenho de fazenda e tipografia forte",
        "Escudo heráldico com cabeça de boi, estilo premium"
    ];

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                setSelectedImage(event.target?.result as string);
                setGeneratedImage(null);
                setError(null);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleGenerate = async () => {
        if (mode === 'edit' && !selectedImage) {
            setError("Por favor, selecione uma imagem para editar.");
            return;
        }
        if (!prompt.trim()) {
            setError("Por favor, descreva o que você deseja criar ou editar.");
            return;
        }

        setLoading(true);
        setError(null);

        try {
            const apiKey = (import.meta as any).env.VITE_AI_API_KEY || (import.meta as any).env.API_KEY || (process.env as any).API_KEY;
            const ai = new GoogleGenAI({ apiKey });

            let contents;
            if (mode === 'edit' && selectedImage) {
                const base64Data = selectedImage.split(',')[1];
                const mimeType = selectedImage.split(';')[0].split(':')[1];
                contents = {
                    parts: [
                        { inlineData: { data: base64Data, mimeType: mimeType } },
                        { text: `Edite esta imagem: ${prompt}` }
                    ]
                };
            } else {
                // Modo Criação de Logo
                contents = {
                    parts: [
                        { text: `Crie uma logomarca profissional e sofisticada com as seguintes características: ${prompt}. A logo deve ser centralizada, com fundo limpo, estilo vetorizado, cores sólidas, design de alta qualidade para frigorífico e agronegócio.` }
                    ]
                };
            }

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: contents,
                config: {
                    imageConfig: {
                        aspectRatio: "1:1"
                    }
                }
            });

            let foundImage = false;
            if (response.candidates && response.candidates[0].content && response.candidates[0].content.parts) {
                for (const part of response.candidates[0].content.parts) {
                    if (part.inlineData) {
                        const generatedBase64 = part.inlineData.data;
                        const generatedMimeType = part.inlineData.mimeType || 'image/png';
                        setGeneratedImage(`data:${generatedMimeType};base64,${generatedBase64}`);
                        foundImage = true;
                        break;
                    }
                }
            }

            if (!foundImage) {
                setError("O modelo não conseguiu gerar a imagem. Tente descrever com outras palavras.");
            }

        } catch (err: any) {
            setError("Erro ao conectar com a IA. Verifique sua conexão.");
        } finally {
            setLoading(false);
        }
    };

    const handleDownload = () => {
        if (generatedImage) {
            const link = document.createElement('a');
            link.href = generatedImage;
            link.download = `frigogest_ai_${mode}_${Date.now()}.png`;
            link.click();
        }
    };

    return (
        <div className="p-4 md:p-8 min-h-screen bg-gray-50 text-gray-900 animate-fade-in relative pb-20">
            <div className="flex flex-col md:flex-row justify-between items-start mb-8 gap-4">
                <div>
                    <button onClick={onBack} className="text-white bg-blue-600 hover:bg-blue-700 p-3 rounded-xl border border-blue-700 transition-all hover:shadow-md active:scale-95 flex items-center gap-2 mb-4">
                        <ArrowLeft size={20} />
                        <span className="font-bold text-sm">Voltar</span>
                    </button>
                    <div className="flex items-center gap-3">
                        <div className="bg-fuchsia-600 p-2 rounded-lg">
                            <Wand2 size={24} className="text-white" />
                        </div>
                        <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Sala de Inteligência</h1>
                    </div>
                    <p className="text-gray-600 text-base mt-1">Crie sua marca ou edite fotos de produtos com Inteligência Artificial.</p>
                </div>
            </div>

            {/* Seletor de Modo */}
            <div className="flex gap-2 mb-8 bg-gray-100 p-1 rounded-xl border border-gray-200 w-full max-w-md">
                <button
                    onClick={() => { setMode('edit'); setGeneratedImage(null); }}
                    className={`flex-1 py-3 rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-all ${mode === 'edit' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-600 hover:text-gray-900'}`}
                >
                    <ImageIcon size={18} /> Editar Foto
                </button>
                <button
                    onClick={() => { setMode('logo'); setGeneratedImage(null); }}
                    className={`flex-1 py-3 rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-all ${mode === 'logo' ? 'bg-fuchsia-600 text-white shadow-md' : 'text-gray-600 hover:text-gray-900'}`}
                >
                    <Palette size={18} /> Criar Logo
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="flex flex-col gap-6">
                    {mode === 'edit' && (
                        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
                            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <ImageIcon size={20} className="text-blue-600" /> 1. Carregar Foto do Produto
                            </h3>
                            <div
                                onClick={() => fileInputRef.current?.click()}
                                className={`relative w-full aspect-video rounded-xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all overflow-hidden group ${selectedImage ? 'border-gray-300 bg-gray-50' : 'border-gray-300 hover:border-blue-500 hover:bg-gray-50'}`}
                            >
                                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
                                {selectedImage ? (
                                    <img src={selectedImage} alt="Original" className="w-full h-full object-contain" />
                                ) : (
                                    <div className="text-center">
                                        <Upload size={48} className="mx-auto text-gray-400 mb-2" />
                                        <p className="text-gray-600">Clique para subir a foto</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
                        <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                            <Sparkles size={20} className="text-fuchsia-600" /> {mode === 'edit' ? '2. Instruções de Edição' : '1. Descreva sua Logo'}
                        </h3>

                        <textarea
                            className="w-full bg-white border border-gray-300 rounded-xl p-4 text-gray-900 focus:ring-2 focus:ring-fuchsia-600 outline-none resize-none h-32 placeholder-gray-400"
                            placeholder={mode === 'edit' ? "Ex: Remova o fundo..." : "Ex: Uma logo minimalista com um touro e o nome 'Frigo Prime' em letras douradas..."}
                            value={prompt}
                            onChange={e => setPrompt(e.target.value)}
                        />

                        <div className="flex flex-wrap gap-2 mt-4">
                            {(mode === 'edit' ? quickPromptsEdit : quickPromptsLogo).map((p, idx) => (
                                <button key={idx} onClick={() => setPrompt(p)} className="text-[10px] bg-gray-100 hover:bg-fuchsia-50 text-gray-600 border border-gray-300 px-3 py-1.5 rounded-full transition-colors">
                                    {p}
                                </button>
                            ))}
                        </div>

                        {error && <div className="mt-4 p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded-lg flex items-center gap-2"><AlertCircle size={16} /> {error}</div>}

                        <button
                            onClick={handleGenerate}
                            disabled={loading || (mode === 'edit' && !selectedImage) || !prompt}
                            className={`w-full mt-6 py-4 rounded-xl font-bold text-white shadow-md transition-all flex items-center justify-center gap-2 ${loading ? 'bg-gray-400' : mode === 'edit' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-fuchsia-600 hover:bg-fuchsia-700'}`}
                        >
                            {loading ? <Loader2 size={20} className="animate-spin" /> : <Wand2 size={20} />}
                            {loading ? "Aguarde, a IA está criando..." : mode === 'edit' ? "Aplicar Edição" : "Criar Minha Marca"}
                        </button>
                    </div>
                </div>

                <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm flex flex-col min-h-[500px]">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                            <Sparkles size={20} className="text-emerald-600" /> Resultado da IA
                        </h3>
                        {generatedImage && (
                            <button onClick={handleDownload} className="bg-gray-100 hover:bg-gray-200 text-gray-900 px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 border border-gray-300">
                                <Download size={16} /> Baixar Logo
                            </button>
                        )}
                    </div>
                    <div className="flex-1 bg-gray-50 rounded-xl border border-gray-200 flex items-center justify-center overflow-hidden">
                        {loading ? (
                            <div className="text-center">
                                <Loader2 size={48} className="animate-spin text-fuchsia-600 mx-auto mb-4" />
                                <p className="text-fuchsia-600 font-bold animate-pulse">Desenhando sua marca...</p>
                            </div>
                        ) : generatedImage ? (
                            <img src={generatedImage} alt="IA Generated" className="max-w-full max-h-full object-contain" />
                        ) : (
                            <div className="text-center text-gray-400 p-8">
                                <Palette size={64} className="mx-auto mb-4 opacity-20" />
                                <p>Preencha os dados ao lado para ver a mágica acontecer.</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AIEditor;
