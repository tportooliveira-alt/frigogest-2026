import React, { useState, useMemo } from 'react';
import { StockItem, Batch, StockType, Sale, Client } from '../types';
import { getTypeName } from '../constants';
import { calculateDaysInStock, formatWeight, formatCurrency } from '../utils/helpers';
import { AlertTriangle, Scale, History, DollarSign, ArrowLeft, ChevronDown, ChevronRight, Package, Search, FileText, Folder, FolderOpen, Tag, Calendar, Database, Zap, Activity, ShieldCheck } from 'lucide-react';

interface StockProps {
  stock: StockItem[];
  batches: Batch[];
  sales: Sale[];
  clients: Client[];
  onBack: () => void;
}

const Stock: React.FC<StockProps> = ({ stock, batches, sales, clients, onBack }) => {
  const [viewMode, setViewMode] = useState<'available' | 'sold'>('available');
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedBatches, setExpandedBatches] = useState<string[]>([]);

  const availableStock = stock.filter(s => s.status === 'DISPONIVEL');
  const soldStock = stock.filter(s => s.status === 'VENDIDO');

  // Group Stock by Batch -> Then by Sequence
  const inventoryByBatch = useMemo(() => {
    const batchGroups = new Map<string, { batch: Batch | undefined, items: StockItem[], sequences: Map<number, StockItem[]> }>();

    availableStock.forEach(item => {
      if (searchTerm && !item.id_completo.toLowerCase().includes(searchTerm.toLowerCase()) && !item.id_lote.toLowerCase().includes(searchTerm.toLowerCase())) {
        return;
      }
      if (!batchGroups.has(item.id_lote)) {
        const batchInfo = batches.find(b => b.id_lote === item.id_lote);
        batchGroups.set(item.id_lote, { batch: batchInfo, items: [], sequences: new Map() });
      }
      const group = batchGroups.get(item.id_lote)!;
      group.items.push(item);
      if (!group.sequences.has(item.sequencia)) group.sequences.set(item.sequencia, []);
      group.sequences.get(item.sequencia)!.push(item);
    });

    return Array.from(batchGroups.values()).sort((a, b) => {
      const dateA = a.batch ? new Date(a.batch.data_recebimento).getTime() : 0;
      const dateB = b.batch ? new Date(b.batch.data_recebimento).getTime() : 0;
      return dateB - dateA;
    });
  }, [availableStock, batches, searchTerm]);

  const toggleBatch = (batchId: string) => {
    setExpandedBatches(prev => prev.includes(batchId) ? prev.filter(id => id !== batchId) : [...prev, batchId]);
  };

  const soldHistory = useMemo(() => {
    return soldStock.map(item => {
      const sale = sales.find(s => s.id_completo === item.id_completo);
      const client = sale ? clients.find(c => c.id_ferro === sale.id_cliente) : null;
      return { item, sale, client };
    }).sort((a, b) => {
      if (a.sale && b.sale) return new Date(b.sale.data_venda).getTime() - new Date(a.sale.data_venda).getTime();
      return 0;
    });
  }, [soldStock, sales, clients]);

  const soldInventoryByBatch = useMemo(() => {
    const batchGroups = new Map<string, { batch: Batch | undefined, items: { item: StockItem, sale: Sale | undefined, client: Client | null }[] }>();
    soldHistory.forEach(({ item, sale, client }) => {
      if (searchTerm && !item.id_completo.toLowerCase().includes(searchTerm.toLowerCase()) && !item.id_lote.toLowerCase().includes(searchTerm.toLowerCase())) return;
      if (!batchGroups.has(item.id_lote)) {
        const batchInfo = batches.find(b => b.id_lote === item.id_lote);
        batchGroups.set(item.id_lote, { batch: batchInfo, items: [] });
      }
      batchGroups.get(item.id_lote)!.items.push({ item, sale, client });
    });
    return Array.from(batchGroups.values()).sort((a, b) => {
      const dateA = a.batch ? new Date(a.batch.data_recebimento).getTime() : 0;
      const dateB = b.batch ? new Date(b.batch.data_recebimento).getTime() : 0;
      return dateB - dateA;
    });
  }, [soldHistory, batches, searchTerm]);

  const totalCashFlow = soldHistory.reduce((acc, curr) => acc + (curr.sale ? (curr.sale.peso_real_saida * curr.sale.preco_venda_kg) : 0), 0);

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gray-50 text-gray-900 pb-20 font-sans selection:bg-blue-200">

      {/* TECHNICAL HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-6 relative">
        <div className="relative z-10">
          <button onClick={onBack} className="text-white bg-blue-600 hover:bg-blue-700 p-3 rounded-xl border border-blue-700 transition-all hover:shadow-md active:scale-95 flex items-center gap-2 mb-4">
            <ArrowLeft size={20} />
            <span className="font-bold text-sm">Voltar</span>
          </button>
          <div className="flex items-center gap-5">
            <div className="bg-white p-3.5 rounded-2xl border border-gray-200 shadow-sm">
              <Database size={28} className="text-blue-600" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-gray-900">Gestão de Estoque</h2>
              <div className="flex items-center gap-3 mt-1.5 text-sm text-gray-600 font-semibold">
                <span className="flex items-center gap-1.5"><ShieldCheck size={14} className="text-emerald-500" /> Sincronizado</span>
                <span className="text-gray-300">|</span>
                <span>Total: {availableStock.length} itens</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 items-center w-full md:w-auto z-10">
          <div className="relative group w-full sm:w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-600 transition-colors" size={18} />
            <input
              type="text"
              placeholder="Buscar por lote ou ID..."
              className="bg-white border border-gray-300 rounded-xl pl-12 pr-6 py-3 text-sm font-medium text-gray-900 focus:ring-2 focus:ring-blue-500 outline-none shadow-sm placeholder-gray-400 w-full"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex bg-gray-100 p-1.5 rounded-xl border border-gray-200">
            <button
              onClick={() => setViewMode('available')}
              className={`px-6 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${viewMode === 'available' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-600 hover:text-gray-900'}`}
            >
              <Scale size={14} /> Disponível
            </button>
            <button
              onClick={() => setViewMode('sold')}
              className={`px-6 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${viewMode === 'sold' ? 'bg-emerald-600 text-white shadow-md' : 'text-gray-600 hover:text-gray-900'}`}
            >
              <History size={14} /> Vendido
            </button>
          </div>
        </div>
      </div>

      {viewMode === 'available' ? (
        <div className="space-y-6 animate-fade-in-up max-w-[1500px] mx-auto">
          {inventoryByBatch.length === 0 && (
            <div className="p-32 text-center border-2 border-dashed border-gray-300 rounded-3xl bg-gray-100">
              <Database size={60} className="mx-auto mb-6 text-gray-400" />
              <p className="text-sm font-semibold text-gray-500">Nenhum item em estoque</p>
            </div>
          )}

          {inventoryByBatch.map(({ batch, items, sequences }) => {
            const batchId = batch ? batch.id_lote : items[0].id_lote;
            const isExpanded = expandedBatches.includes(batchId) || searchTerm.length > 0;
            const totalWeight = items.reduce((acc, i) => acc + i.peso_entrada, 0);
            const daysInStock = batch ? calculateDaysInStock(batch.data_recebimento) : 0;
            const isOld = daysInStock > 8;

            return (
              <div key={batchId} className={`bg-white backdrop-blur-sm border ${isExpanded ? 'border-blue-300 shadow-lg ring-2 ring-blue-100' : 'border-gray-200'} rounded-2xl overflow-hidden transition-all duration-500`}>
                {/* Batch Header */}
                <div
                  onClick={() => toggleBatch(batchId)}
                  className={`p-6 flex flex-col lg:flex-row items-start lg:items-center justify-between cursor-pointer transition-all gap-6 relative group/header ${isExpanded ? 'bg-gray-50' : 'hover:bg-gray-50'}`}
                >
                  <div className="absolute top-4 right-8 text-[9px] font-bold text-gray-300 tracking-wider uppercase">Lote</div>
                  <div className="flex items-center gap-6 w-full lg:w-auto">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-500 ${isExpanded ? 'bg-blue-600 text-white shadow-md' : 'bg-gray-100 text-gray-600 border border-gray-200'}`}>
                      {isExpanded ? <FolderOpen size={20} /> : <Folder size={20} />}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 flex items-center gap-4">
                        {batch?.fornecedor || 'Sem fornecedor'}
                        {isOld && (
                          <span className="flex items-center gap-1.5 text-[10px] font-bold text-amber-600 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
                            <AlertTriangle size={12} /> {daysInStock} dias
                          </span>
                        )}
                      </h3>
                      <div className="flex items-center gap-3 mt-1.5">
                        <span className="font-mono text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                          #{batchId}
                        </span>
                        <div className="w-[1px] h-3 bg-gray-300"></div>
                        <span className="text-[10px] text-gray-500 font-semibold flex items-center gap-1.5">
                          <Calendar size={10} /> {batch?.data_recebimento ? new Date(batch.data_recebimento).toLocaleDateString() : 'N/A'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between w-full lg:w-auto gap-8 lg:gap-16 border-t lg:border-t-0 border-gray-200 pt-6 lg:pt-0 pl-0 lg:pl-10">
                    <div className="text-left lg:text-right">
                      <p className="text-[10px] text-gray-500 font-bold uppercase mb-1.5">Quantidade</p>
                      <p className="text-2xl font-mono font-bold text-gray-900">{items.length} itens</p>
                    </div>
                    <div className="text-left lg:text-right">
                      <p className="text-[10px] text-gray-500 font-bold uppercase mb-1.5">Peso Total</p>
                      <p className="text-2xl font-mono font-bold text-emerald-600 bg-emerald-50 px-4 py-1.5 rounded-xl border border-emerald-200">
                        {formatWeight(totalWeight)}
                      </p>
                    </div>
                    <div className={`transition-all duration-500 ${isExpanded ? 'rotate-90 text-blue-600 scale-110' : 'text-gray-400'}`}>
                      <ChevronRight size={24} />
                    </div>
                  </div>
                </div>

                {/* DETAILED CONTENT */}
                {isExpanded && (
                  <div className="bg-gray-50 p-6 border-t border-gray-200 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 animate-fade-in relative">
                    {Array.from(sequences.entries()).sort((a, b) => a[0] - b[0]).map(([seq, seqItems]) => {
                      const hasInteiro = seqItems.some(i => i.tipo === StockType.INTEIRO);
                      const hasBandaA = seqItems.some(i => i.tipo === StockType.BANDA_A);
                      const hasBandaB = seqItems.some(i => i.tipo === StockType.BANDA_B);
                      const isComplete = hasInteiro || (hasBandaA && hasBandaB);
                      const animalWeight = seqItems.reduce((acc, i) => acc + i.peso_entrada, 0);

                      return (
                        <div key={seq} className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm group/card hover:border-blue-300 hover:shadow-md transition-all duration-300 relative overflow-hidden">
                          {isComplete && <div className="absolute -top-4 -right-4 w-12 h-12 bg-emerald-100 rounded-full blur-lg" />}

                          <div className="flex justify-between items-center mb-4 border-b border-gray-200 pb-3">
                            <div className="flex items-center gap-2">
                              <span className="bg-blue-50 text-blue-700 font-mono text-[10px] font-bold px-2.5 py-1 rounded-lg border border-blue-200">
                                #{String(seq).padStart(3, '0')}
                              </span>
                            </div>
                            <span className="font-mono text-gray-900 text-base font-bold">{formatWeight(animalWeight)}</span>
                          </div>

                          <div className="space-y-2">
                            {seqItems.map(item => (
                              <div key={item.id_completo} className="flex justify-between items-center text-xs group/item py-1">
                                <span className="text-gray-600 flex items-center gap-2 font-semibold">
                                  <div className={`w-2 h-2 rounded-full ${item.tipo === StockType.BANDA_A ? 'bg-blue-500' :
                                    item.tipo === StockType.BANDA_B ? 'bg-purple-500' : 'bg-gray-500'
                                    }`} />
                                  {getTypeName(item.tipo)}
                                </span>
                                <span className="font-mono text-gray-700 font-bold bg-gray-100 px-2 py-1 rounded group-hover/item:text-blue-600 group-hover/item:bg-blue-50 transition-all">
                                  {formatWeight(item.peso_entrada)}
                                </span>
                              </div>
                            ))}
                            {!isComplete && !hasInteiro && (
                              <div className="mt-3 pt-2 border-t border-gray-200 text-[10px] text-amber-600 font-bold flex items-center gap-2">
                                <Activity size={10} /> Incompleto: falta {hasBandaA ? 'Banda B' : 'Banda A'}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="animate-fade-in space-y-12 max-w-[1500px] mx-auto">
          {/* RESUMO DE VENDAS */}
          <div className="bg-white border border-gray-200 p-10 rounded-3xl shadow-md relative overflow-hidden">
            <div className="flex flex-col md:flex-row justify-between items-end gap-10 relative z-10">
              <div>
                <p className="text-emerald-600 font-bold mb-4 flex items-center gap-3 text-xs">
                  <div className="w-2 h-2 rounded-full bg-emerald-600" /> Receita Total de Vendas
                </p>
                <h3 className="text-6xl lg:text-7xl font-bold text-gray-900 font-mono">
                  {formatCurrency(totalCashFlow)}
                </h3>
              </div>
              <div className="bg-gray-50 p-6 rounded-2xl border border-gray-200 text-right min-w-[200px]">
                <p className="text-gray-600 text-xs font-bold mb-2">Total de Itens</p>
                <p className="text-4xl font-bold text-gray-700 font-mono">{soldStock.length}<span className="text-sm opacity-50 ml-2">pcs</span></p>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            {soldInventoryByBatch.map(({ batch, items }) => {
              const batchTotalRevenue = items.reduce((acc, { sale }) => acc + (sale ? (sale.peso_real_saida * sale.preco_venda_kg) : 0), 0);
              const batchTotalCost = items.reduce((acc, { sale, item }) => {
                if (!sale || !batch) return acc;
                return acc + (sale.peso_real_saida * (Number(batch.custo_real_kg) || 0)) + (sale.custo_extras_total || 0);
              }, 0);
              const batchTotalProfit = batchTotalRevenue - batchTotalCost;

              return (
                <div key={batch ? batch.id_lote : 'unknown'} className="bg-white border border-gray-200 rounded-3xl overflow-hidden shadow-sm hover:border-blue-300 transition-all duration-500">
                  <div className="p-8 flex flex-col md:flex-row justify-between items-center gap-8 bg-gray-50 border-b border-gray-200">
                    <div className="flex items-center gap-5">
                      <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
                        <ArchiveIcon size={20} />
                      </div>
                      <div>
                        <h4 className="text-xl font-bold text-gray-900">
                          {batch ? `Lote ${batch.id_lote}` : 'Lote Desconhecido'}
                        </h4>
                        <div className="flex items-center gap-4 mt-1.5 font-semibold text-xs text-gray-600">
                          <span>{batch?.fornecedor || 'Desconhecido'}</span>
                          <div className="w-1 h-1 rounded-full bg-gray-400" />
                          <span className="text-blue-600">Custo: {formatCurrency((batch?.custo_real_kg || 0) * 30)}/arroba</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-10 bg-white border border-gray-200 px-8 py-4 rounded-3xl shadow-sm">
                      <div className="text-right">
                        <p className="text-xs text-gray-600 font-bold mb-1.5">Lucro Real</p>
                        <p className={`text-xl font-mono font-bold ${batchTotalProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {formatCurrency(batchTotalProfit)}
                        </p>
                      </div>
                      <div className="w-[1px] h-10 bg-gray-200"></div>
                      <div className="text-right">
                        <p className="text-xs text-gray-600 font-bold mb-1.5">Quantidade</p>
                        <span className="text-xl font-bold text-gray-700 font-mono">{items.length}</span>
                      </div>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm text-gray-700">
                      <thead className="bg-gray-50 text-gray-700 font-bold text-xs">
                        <tr>
                          <th className="px-10 py-6">Data</th>
                          <th className="px-10 py-6">ID / Tipo</th>
                          <th className="px-10 py-6">Comprador</th>
                          <th className="px-10 py-6 text-right">Peso</th>
                          <th className="px-10 py-6 text-right">Valor Venda</th>
                          <th className="px-10 py-6 text-right">Lucro</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {items.map(({ item, sale, client }) => {
                          const revenue = sale ? (sale.peso_real_saida * sale.preco_venda_kg) : 0;
                          const costKg = batch ? (Number(batch.custo_real_kg) || 0) : 0;
                          const cost = sale ? (sale.peso_real_saida * costKg) + (sale.custo_extras_total || 0) : 0;
                          const profit = revenue - cost;

                          return (
                            <tr key={item.id_completo} className="hover:bg-blue-50 transition-colors">
                              <td className="px-10 py-6 font-mono text-gray-600 text-sm">
                                {sale ? new Date(sale.data_venda).toLocaleDateString() : 'N/A'}
                              </td>
                              <td className="px-10 py-6">
                                <div className="font-bold text-gray-900 text-sm">{item.id_completo}</div>
                                <div className="text-xs text-gray-500 font-semibold mt-1">{getTypeName(item.tipo)}</div>
                              </td>
                              <td className="px-10 py-6">
                                {client ? (
                                  <span className="text-gray-700 font-bold text-sm">{client.nome_social}</span>
                                ) : (
                                  <span className="text-gray-400 italic text-sm">{sale?.nome_cliente || 'Cliente'}</span>
                                )}
                              </td>
                              <td className="px-10 py-6 text-right font-mono text-gray-700 font-semibold">
                                {sale ? formatWeight(sale.peso_real_saida) : '-'}
                              </td>
                              <td className="px-10 py-6 text-right font-mono font-bold text-blue-700">
                                {formatCurrency(revenue)}
                              </td>
                              <td className="px-10 py-6 text-right font-mono font-bold">
                                <span className={profit >= 0 ? 'text-emerald-600' : 'text-rose-600'}>
                                  {formatCurrency(profit)}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

const ArchiveIcon = ({ size }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="21 8 21 21 3 21 3 8"></polyline><rect x="1" y="3" width="22" height="5"></rect><line x1="10" y1="12" x2="14" y2="12"></line></svg>;

export default Stock;