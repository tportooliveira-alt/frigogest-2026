import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Batch, StockItem, StockType } from '../types';
import { PackagePlus, X, PlusCircle, ArrowLeft, RefreshCw, Trash2, Scale, Calculator, CheckCircle, Package, Zap, Activity, ShieldCheck, Thermometer } from 'lucide-react';
import { calculateRealCost, formatCurrency, formatWeight } from '../utils/helpers';

interface BatchesProps {
  batches: Batch[];
  stock: StockItem[];
  addBatch: (b: Batch) => Promise<{ success: boolean; error?: string }>;
  deleteBatch: (id: string) => void;
  addStockItem: (item: StockItem) => Promise<any>;
  updateStockItem: (id: string, updates: Partial<StockItem>) => void;
  removeStockItem?: (id: string) => void;
  registerBatchFinancial: (batch: Batch) => Promise<void>;
  onBack: () => void;
  onGoToStock: () => void;
}

const Batches: React.FC<BatchesProps> = ({ batches, stock, addBatch, deleteBatch, addStockItem, updateStockItem, removeStockItem, registerBatchFinancial, onBack, onGoToStock }) => {
  const weightInputRef = useRef<HTMLInputElement>(null);
  const [selectedBatchId, setSelectedBatchId] = useState<string | null>(null);
  const [showFinalizationModal, setShowFinalizationModal] = useState(false);

  const generateNextId = () => {
    const year = new Date().getFullYear();
    const prefix = `L${year}-`;
    const currentYearBatches = batches.filter(b => b.id_lote.startsWith(prefix));
    if (currentYearBatches.length === 0) return `${prefix}001`;
    const maxSeq = currentYearBatches.reduce((max, b) => {
      const parts = b.id_lote.split('-');
      if (parts.length < 2) return max;
      const seq = parseInt(parts[1]);
      return isNaN(seq) ? max : Math.max(max, seq);
    }, 0);
    return `${prefix}${String(maxSeq + 1).padStart(3, '0')}`;
  };

  const [newBatch, setNewBatch] = useState<any>({
    id_lote: generateNextId(),
    fornecedor: '',
    data_recebimento: new Date().toISOString().split('T')[0],
    peso_total_romaneio: 0,
    valor_compra_total: 0,
    frete: 0,
    gastos_extras: 0,
    pagamento_a_vista: true,
    forma_pagamento: 'PIX'
  } as any);

  const selectedBatch = useMemo(() => batches.find(b => b.id_lote === selectedBatchId), [selectedBatchId, batches]);
  const [draftItems, setDraftItems] = useState<StockItem[]>([]);

  const batchSummary = useMemo(() => {
    if (!selectedBatchId || !selectedBatch) return null;
    const savedItems = stock.filter(s => s.id_lote === selectedBatchId);
    const allItems = [...savedItems, ...draftItems.filter(d => d.id_lote === selectedBatchId)];
    const totalWeighed = allItems.reduce((acc, i) => acc + i.peso_entrada, 0);
    const nfWeight = selectedBatch.peso_total_romaneio;
    const diff = totalWeighed - nfWeight;
    const percent = nfWeight > 0 ? (totalWeighed / nfWeight) * 100 : 0;
    return { totalWeighed, nfWeight, diff, percent, count: allItems.length };
  }, [selectedBatchId, selectedBatch, stock, draftItems]);

  const [newItemEntry, setNewItemEntry] = useState({
    sequencia: '1',
    tipo: StockType.BANDA_A.toString(),
    peso: ''
  });

  useEffect(() => {
    if (selectedBatchId && weightInputRef.current) weightInputRef.current.focus();
  }, [selectedBatchId]);

  const simulatedCost = calculateRealCost(
    newBatch.valor_compra_total || 0,
    newBatch.frete || 0,
    newBatch.gastos_extras || 0,
    newBatch.peso_total_romaneio || 0
  );

  const handleBatchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const loteId = newBatch.id_lote || generateNextId();
    if (!newBatch.peso_total_romaneio) return;
    const batchToSave: Batch = { ...(newBatch as Batch), id_lote: loteId, custo_real_kg: simulatedCost };
    const result = await addBatch(batchToSave);
    if (result && result.success) setSelectedBatchId(loteId);
  };

  const romaneioItems = useMemo(() => {
    if (!selectedBatchId) return [];
    const savedItems = stock.filter(item => item.id_lote === selectedBatchId);
    const allItems = [...savedItems, ...draftItems.filter(d => d.id_lote === selectedBatchId)];
    const grouped = new Map<number, StockItem[]>();
    allItems.forEach(item => {
      if (!grouped.has(item.sequencia)) grouped.set(item.sequencia, []);
      grouped.get(item.sequencia)?.push(item);
    });
    return Array.from(grouped.entries()).map(([seq, groupItems]) => ({
      sequencia: seq,
      bandaA: groupItems.find(i => i.tipo === StockType.BANDA_A),
      bandaB: groupItems.find(i => i.tipo === StockType.BANDA_B),
      inteiro: groupItems.find(i => i.tipo === StockType.INTEIRO),
      totalWeight: groupItems.reduce((sum, i) => sum + i.peso_entrada, 0)
    })).sort((a, b) => a.sequencia - b.sequencia);
  }, [selectedBatchId, stock, draftItems]);

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBatchId || !newItemEntry.sequencia || !newItemEntry.peso) return;
    const seq = parseInt(newItemEntry.sequencia);
    const type = parseInt(newItemEntry.tipo) as StockType;
    const typeLabel = type === StockType.BANDA_A ? 'BANDA_A' : type === StockType.BANDA_B ? 'BANDA_B' : 'INTEIRO';
    const weight = parseFloat(newItemEntry.peso);
    const id_completo = `${selectedBatchId}-${String(seq).padStart(3, '0')}-${typeLabel}`;

    const itemToAdd = {
      id_completo,
      id_lote: selectedBatchId,
      sequencia: seq,
      tipo: type,
      peso_entrada: weight,
      status: 'DISPONIVEL',
      data_entrada: selectedBatch?.data_recebimento || new Date().toISOString().split('T')[0]
    };

    setDraftItems(prev => [...prev, itemToAdd as StockItem]);
    let nextSeq = seq;
    let nextType = type;
    if (type === StockType.INTEIRO) { nextSeq = seq + 1; nextType = StockType.BANDA_A; }
    else if (type === StockType.BANDA_A) { nextSeq = seq; nextType = StockType.BANDA_B; }
    else if (type === StockType.BANDA_B) { nextSeq = seq + 1; nextType = StockType.BANDA_A; }
    setNewItemEntry({ sequencia: nextSeq.toString(), tipo: nextType.toString(), peso: '' });
    setTimeout(() => weightInputRef.current?.focus(), 50);
  };

  const confirmFinalization = async () => {
    if (!selectedBatchId) return;
    const itemsToSave = draftItems.filter(d => d.id_lote === selectedBatchId);
    if (itemsToSave.length === 0) return;
    try {
      for (const item of itemsToSave) { await addStockItem(item); }
      if (selectedBatch) { await registerBatchFinancial(selectedBatch); }
      setDraftItems(prev => prev.filter(d => d.id_lote !== selectedBatchId));
      setShowFinalizationModal(false);
      onGoToStock();
    } catch (e) { }
  };

  return (
    <div className="p-4 md:p-6 min-h-screen bg-gray-50 text-gray-900 relative animate-fade-in pb-20 font-sans selection:bg-blue-200">

      {/* HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 relative">
        <div className="relative z-10">
          <button onClick={onBack} className="text-white bg-blue-600 hover:bg-blue-700 p-3 rounded-xl border border-blue-700 transition-all hover:shadow-md active:scale-95 flex items-center gap-2 mb-2">
            <ArrowLeft size={20} />
            <span className="font-bold text-sm">Voltar</span>
          </button>
          <div className="flex items-center gap-4">
            <div className="bg-white p-2.5 rounded-xl border border-gray-200 shadow-sm">
              <PackagePlus size={22} className="text-blue-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Recepção de Lotes</h2>
              <div className="flex items-center gap-3 mt-1 text-xs text-gray-500 font-semibold">
                <span className="flex items-center gap-1.5"><ShieldCheck size={10} className="text-emerald-600" /> Balança Pronta</span>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={() => setShowFinalizationModal(true)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-bold text-sm shadow-md active:scale-95 transition-all flex items-center gap-2"
        >
          <CheckCircle size={16} />
          <span>Finalizar Lote</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT: INPUT PANEL */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-sm relative overflow-hidden">
            <h3 className="text-sm font-bold text-gray-900 mb-6 flex items-center gap-2">
              <div className="w-1 h-4 bg-blue-600 rounded-full" /> Novo Lote
            </h3>

            <div className="space-y-4 relative z-10">
              <div className="bg-blue-50 p-3 rounded-xl border border-blue-200">
                <label className="text-xs font-bold text-gray-600 mb-0.5 block">ID do Lote</label>
                <div className="text-xl font-mono font-bold text-blue-700">{newBatch.id_lote}</div>
              </div>

              <div className="space-y-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700 ml-1">Fornecedor</label>
                  <input type="text" className="w-full bg-white border border-gray-300 rounded-xl p-3 text-sm text-gray-900 font-semibold outline-none focus:ring-2 focus:ring-blue-500 transition-all" value={newBatch.fornecedor} onChange={e => setNewBatch({ ...newBatch, fornecedor: e.target.value.toUpperCase() })} placeholder="Nome do fornecedor..." />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-700 ml-1">Data Recebimento</label>
                    <input type="date" className="w-full bg-white border border-gray-300 rounded-xl p-2.5 text-sm text-gray-900 outline-none focus:ring-2 focus:ring-blue-500" value={newBatch.data_recebimento} onChange={e => setNewBatch({ ...newBatch, data_recebimento: e.target.value })} />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-700 ml-1">Peso NF (KG)</label>
                    <input type="number" inputMode="decimal" className="w-full bg-white border border-gray-300 rounded-xl p-2.5 text-sm text-gray-900 font-mono font-bold outline-none focus:ring-2 focus:ring-emerald-500" value={newBatch.peso_total_romaneio} onChange={e => setNewBatch({ ...newBatch, peso_total_romaneio: parseFloat(e.target.value) })} />
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-gray-200 space-y-3">
                <h4 className="text-xs font-bold text-gray-700">Dados Financeiros</h4>
                <div className="bg-gray-50 p-4 rounded-xl space-y-3 border border-gray-200">
                  <div className="relative">
                    <label className="text-xs font-bold text-gray-700 mb-0.5 block">Valor Compra (R$)</label>
                    <input type="number" inputMode="decimal" className="w-full bg-white border border-gray-300 rounded-lg p-3 text-gray-900 font-mono font-bold text-base focus:ring-2 focus:ring-blue-500 outline-none" value={newBatch.valor_compra_total} onChange={e => setNewBatch({ ...newBatch, valor_compra_total: parseFloat(e.target.value) })} />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-gray-600">Frete (R$)</span>
                      <input type="number" inputMode="decimal" className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm text-gray-900 font-mono focus:ring-2 focus:ring-blue-500 outline-none" value={newBatch.frete} onChange={e => setNewBatch({ ...newBatch, frete: parseFloat(e.target.value) })} />
                    </div>
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-gray-600">Extras (R$)</span>
                      <input type="number" inputMode="decimal" className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm text-gray-900 font-mono focus:ring-2 focus:ring-blue-500 outline-none" value={newBatch.gastos_extras} onChange={e => setNewBatch({ ...newBatch, gastos_extras: parseFloat(e.target.value) })} />
                    </div>
                  </div>

                  {/* CUSTO CALCULADO POR KG */}
                  <div className="pt-3 border-t border-gray-200">
                    <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg flex justify-between items-center">
                      <span className="text-xs font-bold text-gray-700">Custo Real/KG:</span>
                      <span className="text-xl font-mono font-bold text-blue-700">{formatCurrency(simulatedCost)}</span>
                    </div>
                  </div>
                </div>
              </div>

              <button onClick={handleBatchSubmit} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-md active:scale-95 transition-all text-sm">Iniciar Lote</button>
            </div>
          </div>
        </div>

        {/* RIGHT: WEIGHING STATION */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {selectedBatch ? (
            <>
              {/* PROGRESS BAR COMPACT */}
              <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-sm relative overflow-hidden">
                <div className="flex justify-between items-end mb-4 relative z-10">
                  <div>
                    <p className="text-xs font-bold text-blue-600 mb-1.5 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-ping" /> Pesagem em Tempo Real
                    </p>
                    <h3 className="text-3xl font-mono font-bold text-gray-900">{formatWeight(batchSummary?.totalWeighed || 0)}</h3>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-bold text-gray-600 mb-0.5">Meta</p>
                    <p className="text-base font-mono font-bold text-gray-700">{formatWeight(selectedBatch.peso_total_romaneio)}</p>
                  </div>
                </div>
                <div className="h-4 w-full bg-gray-100 rounded-full overflow-hidden border border-gray-200 shadow-inner relative">
                  <div className="h-full bg-gradient-to-r from-blue-600 to-blue-500 shadow-md transition-all duration-1000 ease-out relative" style={{ width: `${Math.min(batchSummary?.percent || 0, 100)}%` }}>
                    <div className="absolute inset-0 bg-white/20 opacity-10" />
                  </div>
                </div>
                <div className="flex justify-between mt-2.5 text-xs font-semibold text-gray-600">
                  <span>Progresso: {batchSummary?.percent.toFixed(1)}%</span>
                  <span className={batchSummary && batchSummary.diff < 0 ? 'text-amber-600' : 'text-emerald-600'}>Diferença: {formatWeight(batchSummary?.diff || 0)}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 h-full">
                {/* SCALE INPUT COMPACT */}
                <div className="md:col-span-5">
                  <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-sm relative h-full">
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-3">
                        <div className="col-span-1">
                          <label className="text-xs font-bold text-gray-700 mb-1.5 block">Sequência</label>
                          <input type="number" inputMode="numeric" className="w-full bg-white border border-gray-300 rounded-xl p-3 text-gray-900 font-mono font-bold text-center text-lg outline-none focus:ring-2 focus:ring-blue-500" value={newItemEntry.sequencia} onChange={e => setNewItemEntry({ ...newItemEntry, sequencia: e.target.value })} />
                        </div>
                        <div className="col-span-2">
                          <label className="text-xs font-bold text-gray-700 mb-1.5 block">Tipo</label>
                          <select className="w-full bg-white border border-gray-300 rounded-xl p-3 text-gray-900 text-sm font-bold outline-none h-[46px] focus:ring-2 focus:ring-blue-500" value={newItemEntry.tipo} onChange={e => setNewItemEntry({ ...newItemEntry, tipo: e.target.value })}>
                            <option value={StockType.BANDA_A}>Banda A (Direita)</option>
                            <option value={StockType.BANDA_B}>Banda B (Esquerda)</option>
                            <option value={StockType.INTEIRO}>Inteiro</option>
                          </select>
                        </div>
                      </div>

                      <div className="relative pt-4 border-t border-gray-200">
                        <label className="text-xs font-bold text-gray-700 mb-2 block text-center">Peso da Balança (KG)</label>
                        <div className="bg-gray-50 border-2 border-gray-300 rounded-2xl p-6 text-center shadow-inner relative overflow-hidden focus-within:border-blue-500 transition-all">
                          <input ref={weightInputRef} required type="number" step="0.01" inputMode="decimal" className="w-full bg-transparent text-4xl font-mono text-gray-900 text-center outline-none font-bold placeholder-gray-300" placeholder="00.00" value={newItemEntry.peso} onChange={e => setNewItemEntry({ ...newItemEntry, peso: e.target.value })} />
                        </div>
                      </div>

                      <button onClick={handleAddItem} className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-md active:scale-95 transition-all text-sm">Registrar Peça</button>

                      <div className="bg-blue-50 p-3 rounded-xl border border-blue-200 flex justify-between items-center">
                        <span className="text-xs font-bold text-gray-700">Peso Atual:</span>
                        <span className="text-lg font-mono font-bold text-blue-700">+{formatWeight(newItemEntry.peso ? parseFloat(newItemEntry.peso) : 0)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ITEM LOG COMPACT */}
                <div className="md:col-span-7">
                  <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm h-full flex flex-col">
                    <div className="p-4 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
                      <h4 className="text-sm font-bold text-gray-900">Registro de Peças</h4>
                      <div className="text-xs font-bold text-gray-600 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">{batchSummary?.count} ITENS</div>
                    </div>
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-2 max-h-[400px]">
                      {romaneioItems.reverse().map(row => (
                        <div key={row.sequencia} className="bg-slate-950/50 border border-white/5 p-3 rounded-xl flex justify-between items-center group/row hover:border-indigo-500/30 transition-all">
                          <div className="flex items-center gap-4">
                            <div className="text-base font-mono font-black text-slate-500 uppercase tracking-tighter italic">#{row.sequencia}</div>
                            <div className="flex gap-1.5">
                              {row.bandaA && <div className="bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded text-[8px] font-black font-mono border border-indigo-500/10">A:{formatWeight(row.bandaA.peso_entrada)}</div>}
                              {row.bandaB && <div className="bg-purple-500/10 text-purple-400 px-2 py-0.5 rounded text-[8px] font-black font-mono border border-purple-500/10">B:{formatWeight(row.bandaB.peso_entrada)}</div>}
                              {row.inteiro && <div className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[8px] font-black font-mono border border-white/5">F:{formatWeight(row.inteiro.peso_entrada)}</div>}
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-sm font-mono font-black text-white">{formatWeight(row.totalWeight)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-700 bg-slate-900 border border-slate-800 rounded-[2rem] border-dashed p-12">
              <Package size={60} className="mb-4 opacity-10" />
              <p className="text-[9px] font-black uppercase tracking-[0.5em] opacity-30 italic">Awaiting_Manifest_Wait</p>
            </div>
          )}
        </div>
      </div>

      {/* FINALIZATION MODAL COMPACT */}
      {showFinalizationModal && selectedBatch && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white border border-gray-200 w-full max-w-md rounded-2xl shadow-xl p-8 relative overflow-hidden">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-gray-900 flex items-center gap-3">
                <div className="w-1 h-5 bg-emerald-600 rounded-full" /> Finalizar Lote
              </h3>
              <button onClick={() => setShowFinalizationModal(false)} className="bg-gray-100 p-2 rounded-xl text-gray-600 hover:text-gray-900 transition-all"><X size={18} /></button>
            </div>

            <div className="space-y-6">
              <div className="bg-gray-50 p-6 rounded-2xl border border-gray-200 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-gray-600">Lote</span>
                  <span className="font-mono font-bold text-blue-700">{selectedBatch.id_lote}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-gray-600">Itens</span>
                  <span className="font-mono font-bold text-gray-900">{batchSummary?.count} UNIDADES</span>
                </div>
                <div className="pt-4 border-t border-gray-200 flex justify-between items-center">
                  <span className="text-xs font-bold text-gray-600">Peso Total Verificado</span>
                  <span className="font-mono font-bold text-emerald-600 text-2xl">{formatWeight(batchSummary?.totalWeighed || 0)}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <button onClick={() => setShowFinalizationModal(false)} className="flex-1 bg-gray-200 text-gray-700 font-bold py-3 rounded-xl text-sm hover:bg-gray-300 transition-all">Cancelar</button>
                <button onClick={confirmFinalization} className="flex-[2] bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl text-sm shadow-md active:scale-95 transition-all flex items-center justify-center gap-2">
                  <CheckCircle size={16} /> Confirmar Entrada
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Batches;