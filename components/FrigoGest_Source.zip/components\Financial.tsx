import React, { useState, useMemo } from 'react';
import { Sale, Batch, StockItem, Client, Transaction, PaymentMethod } from '../types';
import { formatCurrency, formatWeight } from '../utils/helpers';
import { Edit2, Save, X, DollarSign, TrendingUp, TrendingDown, PlusCircle, ArrowUpRight, ArrowDownLeft, FileText, PieChart, CalendarClock, CheckCircle, ArrowLeft, Beef, Tag, Wallet, ShoppingBag, Truck, Landmark, Printer, Calendar, Filter, Trash2, ShieldCheck, Activity, ChevronRight, Zap, ShoppingCart } from 'lucide-react';
import { getTypeName } from '../constants';
import { jsPDF } from "jspdf";

interface FinancialProps {
  sales: Sale[];
  batches: Batch[];
  stock: StockItem[];
  clients: Client[];
  transactions: Transaction[];
  updateSaleCost: (id_venda: string, newCost: number) => void;
  addTransaction: (t: Transaction) => void;
  deleteTransaction: (id: string) => void;
  addPartialPayment: (saleId: string, valorPagamento: number, method: PaymentMethod, date: string) => void;
  onBack: () => void;
}

const Financial: React.FC<FinancialProps> = ({ sales, batches, stock, clients, transactions, updateSaleCost, addTransaction, deleteTransaction, addPartialPayment, onBack }) => {

  const [activeTab, setActiveTab] = useState<'cashflow' | 'receivables' | 'profit'>('cashflow');
  const [showTransactionForm, setShowTransactionForm] = useState(false);

  // --- STATE DE FILTROS ---
  const [filterStartDate, setFilterStartDate] = useState(() => {
    const date = new Date();
    date.setDate(1);
    return date.toISOString().split('T')[0];
  });
  const [filterEndDate, setFilterEndDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });

  const [newTransaction, setNewTransaction] = useState<Partial<Transaction>>({
    descricao: '',
    valor: 0,
    tipo: 'SAIDA',
    categoria: 'OPERACIONAL',
    data: new Date().toISOString().split('T')[0]
  });
  const [saleToPay, setSaleToPay] = useState<Sale | null>(null);
  const [receiveDate, setReceiveDate] = useState(new Date().toISOString().split('T')[0]);
  const [receiveMethod, setReceiveMethod] = useState<PaymentMethod>('PIX');
  const [partialPaymentAmount, setPartialPaymentAmount] = useState<string>('');

  const openTransactionForm = (tipo: 'ENTRADA' | 'SAIDA') => {
    setNewTransaction({
      descricao: '',
      valor: 0,
      tipo,
      categoria: tipo === 'SAIDA' ? 'OPERACIONAL' : 'VENDA',
      data: new Date().toISOString().split('T')[0]
    });
    setShowTransactionForm(true);
  };

  const getSaleBalance = (sale: Sale) => {
    const valorTotal = sale.weight_out ? (sale.weight_out * sale.price_kg) : (sale.peso_real_saida * sale.preco_venda_kg);
    const valorPago = (sale as any).valor_pago || 0;
    const saldoDevedor = valorTotal - valorPago;
    return { valorTotal, valorPago, saldoDevedor };
  };

  const confirmPartialPayment = () => {
    if (!saleToPay || !partialPaymentAmount) return;
    const valor = parseFloat(partialPaymentAmount.replace(',', '.'));
    const { saldoDevedor } = getSaleBalance(saleToPay);

    if (isNaN(valor) || valor <= 0 || valor > saldoDevedor + 0.01) {
      alert("⚠️ Valor inválido!");
      return;
    }

    addPartialPayment(saleToPay.id_venda, valor, receiveMethod, receiveDate);
    setSaleToPay(null);
    setPartialPaymentAmount('');
  };

  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => t.data >= filterStartDate && t.data <= filterEndDate)
      .sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime());
  }, [transactions, filterStartDate, filterEndDate]);

  const transactionsByDate = useMemo(() => {
    const groups: Record<string, Transaction[]> = {};
    filteredTransactions.forEach(t => {
      if (!groups[t.data]) groups[t.data] = [];
      groups[t.data].push(t);
    });
    return groups;
  }, [filteredTransactions]);

  const totalBalanceGlobal = transactions.filter(t => t.tipo === 'ENTRADA').reduce((acc, t) => acc + t.valor, 0) -
    transactions.filter(t => t.tipo === 'SAIDA').reduce((acc, t) => acc + t.valor, 0);

  const pendingSales = sales
    .filter(s => {
      const { saldoDevedor } = getSaleBalance(s);
      return saldoDevedor > 0.01;
    })
    .sort((a, b) => new Date(a.data_vencimento).getTime() - new Date(b.data_vencimento).getTime());

  const totalReceivable = pendingSales.reduce((acc, s) => {
    const { saldoDevedor } = getSaleBalance(s);
    return acc + saldoDevedor;
  }, 0);

  const getSaleDetails = (sale: Sale) => {
    const item = stock.find(s => s.id_completo === sale.id_completo);
    const batch = item ? batches.find(b => b.id_lote === item.id_lote) : null;
    const revenue = sale.peso_real_saida * sale.preco_venda_kg;
    const costKg = batch ? (Number(batch.custo_real_kg) || 0) : 0;
    const itemWeight = item ? item.peso_entrada : sale.peso_real_saida;
    const cgs = itemWeight * costKg;
    const operationalCost = sale.custo_extras_total || 0;
    const netProfit = revenue - cgs - operationalCost;
    return { revenue, cgs, operationalCost, netProfit };
  };

  const profitTotals = sales.reduce((acc, sale) => {
    const details = getSaleDetails(sale);
    return {
      revenue: acc.revenue + details.revenue,
      cgs: acc.cgs + details.cgs,
      ops: acc.ops + details.operationalCost,
      profit: acc.profit + details.netProfit
    };
  }, { revenue: 0, cgs: 0, ops: 0, profit: 0 });

  return (
    <div className="p-4 md:p-6 min-h-screen bg-gray-50 text-gray-900 animate-fade-in pb-20 font-sans selection:bg-blue-200">

      {/* HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 relative">
        <div className="relative z-10">
          <button onClick={onBack} className="text-white bg-blue-600 hover:bg-blue-700 p-3 rounded-xl border border-blue-700 transition-all hover:shadow-md active:scale-95 flex items-center gap-2 mb-2">
            <ArrowLeft size={20} />
            <span className="font-bold text-sm">Voltar</span>
          </button>
          <div className="flex items-center gap-4">
            <div className="bg-white p-2.5 rounded-xl border border-gray-200 shadow-sm">
              <Landmark size={22} className="text-blue-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Financeiro</h2>
              <div className="flex items-center gap-2 mt-1 text-xs text-gray-500 font-semibold">
                <span className="flex items-center gap-1.5"><ShieldCheck size={10} className="text-emerald-600" /> Sincronizado</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex bg-gray-100 border border-gray-200 p-1 rounded-xl w-full md:w-auto overflow-x-auto shadow-sm relative">
          {['cashflow', 'receivables', 'profit'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`flex-1 md:flex-none px-5 py-2 rounded-lg text-sm font-bold transition-all flex items-center justify-center gap-2 whitespace-nowrap ${activeTab === tab ? 'bg-blue-600 text-white shadow-md' : 'text-gray-600 hover:text-gray-900'}`}
            >
              {tab === 'cashflow' && <Wallet size={14} />}
              {tab === 'receivables' && <CalendarClock size={14} />}
              {tab === 'profit' && <PieChart size={14} />}
              <span className="hidden sm:inline">{tab === 'cashflow' ? 'Fluxo de Caixa' : tab === 'receivables' ? 'A Receber' : 'Resultados'}</span>
            </button>
          ))}
        </div>
      </div>

      {/* CONTENT: CASHFLOW */}
      {activeTab === 'cashflow' && (
        <div className="animate-fade-in grid grid-cols-1 lg:grid-cols-12 gap-6 max-w-[1400px] mx-auto">
          {/* LEFT: SUMMARY */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-sm relative overflow-hidden">
              <div className="relative z-10">
                <p className="text-xs text-gray-600 font-bold mb-3 flex items-center gap-2">Saldo Total</p>
                <h3 className={`text-3xl font-mono font-bold ${totalBalanceGlobal >= 0 ? 'text-gray-900' : 'text-rose-600'}`}>
                  {formatCurrency(totalBalanceGlobal)}
                </h3>
                <div className="mt-6 grid grid-cols-2 gap-2">
                  <button onClick={() => openTransactionForm('ENTRADA')} className="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold py-3 rounded-lg flex items-center justify-center gap-2 shadow-md active:scale-95">
                    <ArrowUpRight size={14} /> Entrada
                  </button>
                  <button onClick={() => openTransactionForm('SAIDA')} className="bg-rose-600 hover:bg-rose-700 text-white text-sm font-bold py-3 rounded-lg flex items-center justify-center gap-2 shadow-md active:scale-95">
                    <ArrowDownLeft size={14} /> Saída
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-white border border-gray-200 p-5 rounded-2xl space-y-4 shadow-sm">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <span className="text-xs font-bold text-gray-700">Data Início</span>
                  <input type="date" className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm text-gray-900 font-mono outline-none focus:ring-2 focus:ring-blue-500" value={filterStartDate} onChange={e => setFilterStartDate(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <span className="text-xs font-bold text-gray-700">Data Fim</span>
                  <input type="date" className="w-full bg-white border border-gray-300 rounded-lg p-2 text-sm text-gray-900 font-mono outline-none focus:ring-2 focus:ring-blue-500" value={filterEndDate} onChange={e => setFilterEndDate(e.target.value)} />
                </div>
              </div>
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-bold text-sm shadow-md flex items-center justify-center gap-2">
                <FileText size={14} /> Exportar PDF
              </button>
            </div>
          </div>

          {/* RIGHT: TIMELINE */}
          <div className="lg:col-span-8 space-y-4">
            {Object.keys(transactionsByDate).length === 0 ? (
              <div className="p-10 text-center text-gray-400 bg-white border border-gray-200 border-dashed rounded-2xl">
                <p className="text-sm font-semibold">Nenhuma transação no período</p>
              </div>
            ) : (
              <div className="space-y-6">
                {Object.keys(transactionsByDate).sort((a, b) => new Date(b).getTime() - new Date(a).getTime()).map(date => (
                  <div key={date} className="relative group">
                    <div className="sticky top-0 z-20 flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shadow-md relative z-10 text-xs">
                        <Calendar size={16} />
                      </div>
                      <div className="bg-white backdrop-blur-md px-3 py-1 rounded-full border border-gray-200 shadow-sm">
                        <span className="text-sm font-bold text-gray-900">
                          {new Date(date).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    <div className="pl-12 space-y-2">
                      {transactionsByDate[date].map((t) => (
                        <div key={t.id} className="bg-white border border-gray-200 hover:border-blue-300 p-3 rounded-xl transition-all flex items-center justify-between shadow-sm hover:shadow-md">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm ${t.tipo === 'ENTRADA' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                              {t.categoria === 'VENDA' ? <ShoppingCart size={14} /> : <Tag size={14} />}
                            </div>
                            <div>
                              <p className="text-sm font-bold text-gray-900 truncate w-32 sm:w-64">{t.descricao}</p>
                              <span className="text-xs font-semibold text-gray-500">{t.categoria}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={`font-mono font-bold text-sm ${t.tipo === 'ENTRADA' ? 'text-emerald-600' : 'text-rose-600'}`}>
                              {t.tipo === 'ENTRADA' ? '+' : '-'} {formatCurrency(t.valor)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB: RECEIVABLES */}
      {activeTab === 'receivables' && (
        <div className="animate-fade-in space-y-6 max-w-[1200px] mx-auto">
          <div className="bg-white border border-amber-200 p-6 rounded-2xl shadow-sm relative overflow-hidden">
            <h3 className="text-amber-600 font-bold text-sm mb-2">Total a Receber</h3>
            <p className="text-4xl font-mono font-bold text-gray-900">{formatCurrency(totalReceivable)}</p>
          </div>

          <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-gray-700">
                <thead className="bg-gray-50 text-gray-700 font-bold text-xs">
                  <tr>
                    <th className="px-6 py-4">Vencimento</th>
                    <th className="px-6 py-4">Cliente</th>
                    <th className="px-6 py-4 text-right">Valor</th>
                    <th className="px-6 py-4 text-center">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {pendingSales.map(sale => {
                    const { saldoDevedor } = getSaleBalance(sale);
                    const isOverdue = sale.data_vencimento < new Date().toISOString().split('T')[0];
                    return (
                      <tr key={sale.id_venda} className="hover:bg-blue-50 transition-all">
                        <td className="px-6 py-4 font-mono text-sm">
                          <span className={isOverdue ? 'text-rose-600 font-bold' : 'text-gray-700'}>{new Date(sale.data_vencimento).toLocaleDateString()}</span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-gray-900 font-bold text-sm truncate w-24 sm:w-auto">{sale.nome_cliente || 'VAREJO'}</div>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="text-amber-600 font-mono font-bold">{formatCurrency(saldoDevedor)}</div>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button onClick={() => setSaleToPay(sale)} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-bold text-sm shadow-md active:scale-95 transition-all">
                            Receber
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB: PROFIT */}
      {activeTab === 'profit' && (
        <div className="animate-fade-in space-y-6 max-w-[1200px] mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Receita', val: profitTotals.revenue, color: 'text-gray-900' },
              { label: 'Custo Carne', val: profitTotals.cgs, color: 'text-gray-600' },
              { label: 'Despesas', val: profitTotals.ops, color: 'text-amber-600' },
              { label: 'Lucro Líquido', val: profitTotals.profit, color: profitTotals.profit >= 0 ? 'text-emerald-600' : 'text-rose-600', highlight: true }
            ].map((kpi, i) => (
              <div key={i} className={`bg-white border ${kpi.highlight ? 'border-blue-300' : 'border-gray-200'} p-5 rounded-2xl relative overflow-hidden shadow-sm`}>
                <p className="text-xs text-gray-600 font-bold mb-1.5">{kpi.label}</p>
                <p className={`text-xl font-mono font-bold ${kpi.color}`}>{formatCurrency(kpi.val)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SETTLEMENT MODAL */}
      {saleToPay && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white border border-gray-200 w-full max-w-sm rounded-2xl shadow-xl p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold text-gray-900">Registrar Pagamento</h3>
              <button onClick={() => setSaleToPay(null)} className="text-gray-500 hover:text-gray-900"><X size={18} /></button>
            </div>
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
                <p className="text-xs font-bold text-gray-600 mb-1">Cliente</p>
                <p className="text-sm font-bold text-gray-900">{saleToPay.nome_cliente}</p>
                <p className="mt-2 text-lg font-mono font-bold text-amber-600">{formatCurrency(getSaleBalance(saleToPay).saldoDevedor)}</p>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-700">Valor Recebido</label>
                <input type="text" placeholder="0,00" className="w-full bg-white border border-gray-300 rounded-xl p-3 text-gray-900 font-mono font-bold text-center focus:ring-2 focus:ring-emerald-500 outline-none" value={partialPaymentAmount} onChange={e => setPartialPaymentAmount(e.target.value)} />
              </div>
              <button onClick={confirmPartialPayment} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-4 rounded-xl text-sm shadow-md active:scale-95 transition-all flex items-center justify-center gap-2">
                <CheckCircle size={16} /> Confirmar Pagamento
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Financial;