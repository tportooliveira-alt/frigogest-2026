import React, { useState, useMemo } from 'react';
import { Sale, StockItem, Transaction, Batch, Client } from '../types';
import { formatCurrency, formatWeight } from '../utils/helpers';
import { TrendingUp, TrendingDown, Activity, ArrowLeft, LayoutGrid, BarChart2, Sparkles, Loader2, Package, ShoppingCart, DollarSign, Target, Zap, Cpu, ChevronDown, ChevronRight, History } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell, AreaChart, Area, Defs, LinearGradient } from 'recharts';
import { GoogleGenAI } from "@google/genai";

interface DashboardProps {
  sales: Sale[];
  stock: StockItem[];
  transactions: Transaction[];
  batches: Batch[];
  clients: Client[];
  onBack: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ sales, stock, transactions, batches, clients, onBack }) => {
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [expandedBatches, setExpandedBatches] = useState<Set<string>>(new Set());

  const safeSales = Array.isArray(sales) ? sales : [];
  const safeStock = Array.isArray(stock) ? stock : [];
  const safeBatches = Array.isArray(batches) ? batches : [];
  const safeClients = Array.isArray(clients) ? clients : [];

  const totalRevenue = safeSales.reduce((acc, curr) => acc + (curr.peso_real_saida * curr.preco_venda_kg), 0);
  const totalWeightSold = safeSales.reduce((acc, curr) => acc + curr.peso_real_saida, 0);
  const totalBreakage = safeSales.reduce((acc, curr) => acc + (curr.quebra_kg || 0), 0);

  const totalReceivable = safeSales
    .filter(s => s.status_pagamento === 'PENDENTE')
    .reduce((acc, curr) => {
      const total = curr.peso_real_saida * curr.preco_venda_kg;
      const paid = (curr as any).valor_pago || 0;
      return acc + (total - paid);
    }, 0);

  const chartData = safeSales.slice(-12).map((s, idx) => ({
    name: `V${idx + 1}`,
    lucro: (s.lucro_liquido_unitario || 0) * s.peso_real_saida,
    valor: s.peso_real_saida * s.preco_venda_kg
  }));

  // Agrupar vendas por lote
  const salesByBatch = useMemo(() => {
    const grouped = new Map<string, any[]>();

    safeSales.forEach(sale => {
      const item = safeStock.find(s => s.id_completo === sale.id_completo);
      const batch = item ? safeBatches.find(b => b.id_lote === item.id_lote) : null;
      const client = safeClients.find(c => c.id_ferro === sale.id_cliente);
      const batchId = batch?.id_lote || 'sem-lote';

      if (!grouped.has(batchId)) {
        grouped.set(batchId, []);
      }

      const revenue = sale.peso_real_saida * sale.preco_venda_kg;
      const costKg = batch ? (Number(batch.custo_real_kg) || 0) : 0;
      const cost = (sale.peso_real_saida * costKg) + (sale.custo_extras_total || 0);
      const profit = revenue - cost;

      grouped.get(batchId)!.push({
        sale,
        item,
        batch,
        client,
        revenue,
        cost,
        profit
      });
    });

    return Array.from(grouped.entries()).map(([batchId, items]) => {
      const batch = items[0].batch;
      const totalRevenue = items.reduce((sum, i) => sum + i.revenue, 0);
      const totalCost = items.reduce((sum, i) => sum + i.cost, 0);
      const totalProfit = items.reduce((sum, i) => sum + i.profit, 0);

      return {
        batchId,
        batch,
        items,
        totalRevenue,
        totalCost,
        totalProfit,
        supplier: batch?.fornecedor || 'Desconhecido'
      };
    }).sort((a, b) => b.totalRevenue - a.totalRevenue);
  }, [safeSales, safeStock, safeBatches, safeClients]);

  const toggleBatch = (batchId: string) => {
    const newExpanded = new Set(expandedBatches);
    if (newExpanded.has(batchId)) {
      newExpanded.delete(batchId);
    } else {
      newExpanded.add(batchId);
    }
    setExpandedBatches(newExpanded);
  };

  const handleAnalyze = async () => {
    setAnalyzing(true);
    try {
      const apiKey = (import.meta as any).env.VITE_AI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      const model = ai.getGenerativeModel({ model: "gemini-pro" });
      const salesSummary = `Revenue: ${formatCurrency(totalRevenue)}, Vol: ${formatWeight(totalWeightSold)}`;
      const prompt = `Analise: ${salesSummary}. 3 insights técnicos curtos.`;
      const result = await model.generateContent(prompt);
      const response = await result.response;
      setAiAnalysis(response.text());
    } catch (error) {
      setAiAnalysis("Core AI link failed. API key required.");
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="p-4 md:p-6 min-h-screen bg-gray-50 text-gray-900 relative animate-fade-in pb-20 font-sans selection:bg-blue-200">

      {/* HEADER COMPACTED */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 relative z-10">
        <div>
          <button onClick={onBack} className="text-white bg-blue-600 hover:bg-blue-700 p-3 rounded-xl border border-blue-700 transition-all hover:shadow-md active:scale-95 flex items-center gap-2 mb-2">
            <ArrowLeft size={20} />
            <span className="font-bold text-sm">Voltar</span>
          </button>
          <div className="flex items-center gap-4">
            <div className="relative bg-white p-2.5 rounded-xl border border-gray-200 shadow-sm">
              <LayoutGrid size={24} className="text-blue-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 leading-none">Painel Geral</h1>
              <span className="text-gray-500 text-xs font-semibold mt-1 block">Visão geral do negócio</span>
            </div>
          </div>
        </div>

        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          className="bg-white border border-blue-300 px-6 py-3 rounded-lg font-bold text-xs transition-all active:scale-95 disabled:opacity-50 text-blue-600 hover:bg-blue-50 shadow-sm"
        >
          {analyzing ? <Loader2 className="animate-spin" size={14} /> : <Cpu size={14} />}
          <span className="ml-2">Analisar com IA</span>
        </button>
      </div>

      {aiAnalysis && (
        <div className="mb-6 bg-blue-50 border border-blue-200 p-6 rounded-2xl relative overflow-hidden shadow-sm">
          <p className="text-sm text-gray-700 whitespace-pre-wrap">{aiAnalysis}</p>
        </div>
      )}

      {/* KPI GRID COMPACTED */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Receita', val: totalRevenue, icon: DollarSign, color: 'text-blue-600' },
          { label: 'A Receber', val: totalReceivable, icon: ShoppingCart, color: 'text-amber-600' },
          { label: 'Volume', val: totalWeightSold, icon: Package, color: 'text-emerald-600', fmt: 'w' },
          { label: 'Quebra', val: totalBreakage, icon: TrendingDown, color: 'text-rose-600', fmt: 'w' }
        ].map((kpi, i) => (
          <div key={i} className="bg-white border border-gray-200 p-5 rounded-xl relative overflow-hidden group shadow-sm hover:shadow-md transition-all">
            <p className="text-gray-500 text-xs font-bold uppercase mb-2">{kpi.label}</p>
            <p className={`text-xl font-mono font-bold ${kpi.color}`}>
              {kpi.fmt === 'w' ? formatWeight(kpi.val) : formatCurrency(kpi.val)}
            </p>
          </div>
        ))}
      </div>

      {/* CHART COMPACTED */}
      <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-sm h-[400px] flex flex-col relative overflow-hidden mb-8">
        <h3 className="text-sm font-bold text-gray-900 flex items-center gap-3 mb-6">
          <div className="w-1.5 h-6 bg-blue-600 rounded-full" />
          Velocidade de Vendas
        </h3>

        <div className="flex-1 w-full min-h-0">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
              <defs>
                <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} opacity={0.5} />
              <XAxis dataKey="name" hide />
              <YAxis tick={{ fill: '#6b7280', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${v / 1000}k`} />
              <Tooltip
                contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e5e7eb', borderRadius: '12px', fontSize: '12px' }}
              />
              <Area type="monotone" dataKey="valor" stroke="#3b82f6" strokeWidth={3} fill="url(#colorVal)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* HISTÓRICO DE VENDAS POR LOTE */}
      <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-sm">
        <h3 className="text-lg font-bold text-gray-900 flex items-center gap-3 mb-6">
          <History size={20} className="text-blue-600" />
          Histórico de Vendas por Lote
        </h3>

        <div className="space-y-4">
          {salesByBatch.map(({ batchId, batch, items, totalRevenue, totalCost, totalProfit, supplier }) => {
            const isExpanded = expandedBatches.has(batchId);

            return (
              <div key={batchId} className={`border ${isExpanded ? 'border-blue-300 shadow-md' : 'border-gray-200'} rounded-xl overflow-hidden transition-all`}>
                <div
                  onClick={() => toggleBatch(batchId)}
                  className="p-6 flex flex-col md:flex-row items-start md:items-center justify-between cursor-pointer hover:bg-gray-50 transition-all gap-4"
                >
                  <div className="flex-1">
                    <h4 className="text-base font-bold text-gray-900">
                      {batch ? `Lote ${batch.id_lote}` : 'Sem Lote'}
                    </h4>
                    <p className="text-sm text-gray-600 font-semibold mt-1">
                      Fornecedor: {supplier} • {items.length} vendas
                    </p>
                  </div>

                  <div className="flex items-center gap-6 flex-wrap">
                    <div className="text-right">
                      <p className="text-xs text-gray-600 font-bold">Custo Total</p>
                      <p className="font-mono font-bold text-gray-700 text-sm">{formatCurrency(totalCost)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-600 font-bold">Receita</p>
                      <p className="font-mono font-bold text-gray-900 text-sm">{formatCurrency(totalRevenue)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-600 font-bold">Lucro</p>
                      <p className={`font-mono font-bold text-sm ${totalProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {formatCurrency(totalProfit)}
                      </p>
                    </div>
                    <div className={`p-2 bg-gray-100 rounded-lg transition-all ${isExpanded ? 'rotate-90 text-blue-600' : 'text-gray-400'}`}>
                      <ChevronRight size={18} />
                    </div>
                  </div>
                </div>

                {isExpanded && (
                  <div className="border-t border-gray-200 bg-gray-50">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-sm">
                        <thead className="bg-gray-100 text-gray-700 font-bold text-xs">
                          <tr>
                            <th className="px-6 py-4">Data</th>
                            <th className="px-6 py-4">Comprador</th>
                            <th className="px-6 py-4">Item</th>
                            <th className="px-6 py-4 text-right">Peso</th>
                            <th className="px-6 py-4 text-right">Valor Vendido</th>
                            <th className="px-6 py-4 text-right">Lucro</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {items.map((entry, idx) => (
                            <tr key={idx} className="hover:bg-blue-50 transition-colors">
                              <td className="px-6 py-4 font-mono text-gray-600 text-xs">
                                {new Date(entry.sale.data_venda).toLocaleDateString()}
                              </td>
                              <td className="px-6 py-4">
                                <div className="font-bold text-gray-900 text-sm">
                                  {entry.client?.nome_social || entry.sale.nome_cliente || 'Varejo'}
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <span className="bg-blue-50 border border-blue-200 px-2 py-1 rounded text-blue-700 font-semibold text-xs">
                                  {entry.item?.id_completo || entry.sale.id_completo}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-right font-mono text-gray-700 font-semibold text-sm">
                                {formatWeight(entry.sale.peso_real_saida)}
                              </td>
                              <td className="px-6 py-4 text-right font-mono font-bold text-blue-700 text-sm">
                                {formatCurrency(entry.revenue)}
                              </td>
                              <td className={`px-6 py-4 text-right font-mono font-bold text-sm ${entry.profit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                                {formatCurrency(entry.profit)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {salesByBatch.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <History size={48} className="mx-auto mb-4 opacity-30" />
              <p className="font-semibold">Nenhuma venda registrada</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;