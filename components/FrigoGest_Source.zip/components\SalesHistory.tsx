import React, { useMemo, useState } from 'react';
import { StockItem, Batch, Sale, Client } from '../types';
import { formatWeight, formatCurrency, exportToCSV } from '../utils/helpers';
import { History, ArrowLeft, Search, Calendar, User, Package, Download, Filter, ChevronDown, ChevronRight, DollarSign, Activity, ShieldCheck, Zap, TrendingUp, TrendingDown, PieChart } from 'lucide-react';

interface SalesHistoryProps {
    stock: StockItem[];
    batches: Batch[];
    sales: Sale[];
    clients: Client[];
    onBack: () => void;
}

type GroupBy = 'date' | 'client' | 'batch';

const SalesHistory: React.FC<SalesHistoryProps> = ({ stock, batches, sales, clients, onBack }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [groupBy, setGroupBy] = useState<GroupBy>('batch');
    const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());

    const toggleGroup = (groupId: string) => {
        const newExpanded = new Set(expandedGroups);
        if (newExpanded.has(groupId)) {
            newExpanded.delete(groupId);
        } else {
            newExpanded.add(groupId);
        }
        setExpandedGroups(newExpanded);
    };

    // 1. Prepare Base Data (Joined)
    const salesData = useMemo(() => {
        return sales.map(sale => {
            const item = stock.find(s => s.id_completo === sale.id_completo);
            const batch = batches.find(b => b.id_lote === (item?.id_lote || ''));
            const client = clients.find(c => c.id_ferro === sale.id_cliente);

            const revenue = sale.peso_real_saida * sale.preco_venda_kg;
            const costKg = batch ? (Number(batch.custo_real_kg) || 0) : 0;
            const itemWeight = item ? item.peso_entrada : sale.peso_real_saida;
            const cost = (itemWeight * costKg) + (sale.custo_extras_total || 0);
            const profit = revenue - cost;

            return { sale, item, batch, client, revenue, cost, profit };
        }).filter(data => {
            if (!searchTerm) return true;
            const term = searchTerm.toLowerCase();
            return (
                data.sale.nome_cliente?.toLowerCase().includes(term) ||
                data.item?.id_completo.toLowerCase().includes(term) ||
                data.batch?.id_lote.toLowerCase().includes(term) ||
                data.batch?.fornecedor.toLowerCase().includes(term)
            );
        }).sort((a, b) => new Date(b.sale.data_venda).getTime() - new Date(a.sale.data_venda).getTime());
    }, [sales, stock, batches, clients, searchTerm]);

    // 2. Totals for Cards
    const totals = useMemo(() => {
        return salesData.reduce((acc, curr) => ({
            revenue: acc.revenue + curr.revenue,
            cost: acc.cost + curr.cost,
            profit: acc.profit + curr.profit,
            count: acc.count + 1
        }), { revenue: 0, cost: 0, profit: 0, count: 0 });
    }, [salesData]);

    // 3. Grouping Logic
    const groupedData = useMemo(() => {
        const groups = new Map<string, typeof salesData>();

        salesData.forEach(entry => {
            let key = '';
            let label = '';
            if (groupBy === 'date') {
                const date = new Date(entry.sale.data_venda);
                key = `${date.getFullYear()}-${date.getMonth()}`;
                label = date.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
                label = label.charAt(0).toUpperCase() + label.slice(1);
            } else if (groupBy === 'client') {
                key = entry.client?.id_ferro || 'unknown';
                label = entry.client ? `${entry.client.nome_social}` : (entry.sale.nome_cliente || 'Cliente');
            } else if (groupBy === 'batch') {
                key = entry.batch?.id_lote || 'unknown';
                label = entry.batch ? `Lote ${entry.batch.id_lote}` : 'Sem Lote';
            }
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key)!.push(entry);
        });

        return Array.from(groups.entries()).map(([key, items]) => {
            const groupRevenue = items.reduce((sum, i) => sum + i.revenue, 0);
            const groupCost = items.reduce((sum, i) => sum + i.cost, 0);
            const groupProfit = items.reduce((sum, i) => sum + i.profit, 0);
            const batch = items[0].batch;
            const supplier = batch?.fornecedor || 'Desconhecido';

            let groupLabel = key;
            if (groupBy === 'date') {
                const date = new Date(items[0].sale.data_venda);
                const monthName = date.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
                groupLabel = monthName.charAt(0).toUpperCase() + monthName.slice(1);
            } else if (groupBy === 'client') {
                groupLabel = items[0].client ? `${items[0].client.nome_social}` : (items[0].sale.nome_cliente || 'Cliente');
            } else if (groupBy === 'batch') {
                groupLabel = items[0].batch ? `Lote ${items[0].batch.id_lote}` : 'Sem Lote';
            }
            return {
                id: key,
                label: groupLabel,
                items,
                totalRevenue: groupRevenue,
                totalCost: groupCost,
                totalProfit: groupProfit,
                supplier,
                batch
            };
        }).sort((a, b) => {
            if (groupBy === 'date') return b.id.localeCompare(a.id);
            return b.totalRevenue - a.totalRevenue;
        });
    }, [salesData, groupBy]);

    const handleExport = () => {
        const data = salesData.map(({ sale, item, batch, revenue, cost, profit }) => ({
            'Data': new Date(sale.data_venda).toLocaleDateString('pt-BR'),
            'Cliente': sale.nome_cliente,
            'Item ID': item?.id_completo || 'N/A',
            'Lote': batch?.id_lote || 'N/A',
            'Peso Saída': formatWeight(sale.peso_real_saida),
            'Preço/Kg': formatCurrency(sale.preco_venda_kg),
            'Receita': formatCurrency(revenue),
            'Custo Aprox': formatCurrency(cost),
            'Lucro': formatCurrency(profit)
        }));
        exportToCSV(data, `Vendas_${new Date().toISOString().split('T')[0]}.csv`);
    };

    return (
        <div className="p-4 md:p-8 min-h-screen bg-gray-50 text-gray-900 animate-fade-in pb-20 font-sans selection:bg-blue-200">
            {/* HEADER */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-6 relative">
                <div className="relative z-10">
                    <button onClick={onBack} className="text-white bg-blue-600 hover:bg-blue-700 p-3 rounded-xl border border-blue-700 transition-all hover:shadow-md active:scale-95 flex items-center gap-2 mb-4">
                        <ArrowLeft size={20} />
                        <span className="font-bold text-sm">Voltar</span>
                    </button>
                    <div className="flex items-center gap-5">
                        <div className="bg-white p-3.5 rounded-2xl border border-gray-200 shadow-sm">
                            <History size={28} className="text-emerald-600" />
                        </div>
                        <div>
                            <h2 className="text-3xl font-bold text-gray-900">Histórico de Vendas</h2>
                            <div className="flex items-center gap-3 mt-1.5 text-xs text-gray-500 font-semibold">
                                <span className="flex items-center gap-1.5"><ShieldCheck size={10} className="text-emerald-600" /> Sincronizado</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto z-10">
                    <div className="relative group">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-600 transition-colors" size={18} />
                        <input
                            type="text"
                            placeholder="Buscar vendas..."
                            className="bg-white border border-gray-300 rounded-2xl pl-12 pr-6 py-4 text-sm font-semibold text-gray-900 focus:ring-2 focus:ring-blue-500 outline-none shadow-sm placeholder-gray-400 w-full md:w-64"
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex bg-gray-100 p-1.5 rounded-2xl border border-gray-200">
                        {[
                            { id: 'date', icon: Calendar, label: 'Por Data' },
                            { id: 'client', icon: User, label: 'Por Cliente' },
                            { id: 'batch', icon: Package, label: 'Por Lote' }
                        ].map((btn) => (
                            <button key={btn.id} onClick={() => setGroupBy(btn.id as any)} className={`px-5 py-3 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${groupBy === btn.id ? 'bg-blue-600 text-white shadow-md' : 'text-gray-600 hover:text-gray-900'}`}>
                                <btn.icon size={14} /> {btn.label}
                            </button>
                        ))}
                    </div>
                    <button onClick={handleExport} className="bg-white hover:bg-emerald-600 text-gray-600 hover:text-white p-4 rounded-2xl border border-gray-200 shadow-sm transition-all active:scale-95 group">
                        <Download size={20} className="group-hover:translate-y-0.5 transition-transform" />
                    </button>
                </div>
            </div>

            {/* KPI CARDS */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                {[
                    { label: 'Receita Total', val: totals.revenue, color: 'text-emerald-600', decal: 'REC' },
                    { label: 'Custo Total', val: totals.cost, color: 'text-rose-600', decal: 'CUS' },
                    { label: 'Lucro Líquido', val: totals.profit, color: 'text-gray-900', decal: 'LUC', highlight: true }
                ].map((kpi, i) => (
                    <div key={i} className={`bg-white p-8 rounded-2xl border ${kpi.highlight ? 'border-blue-300' : 'border-gray-200'} shadow-sm relative overflow-hidden`}>
                        <div className="absolute top-4 right-8 text-xs font-mono font-bold text-gray-200">{kpi.decal}</div>
                        <p className="text-xs text-gray-600 font-bold mb-4 flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-blue-600" /> {kpi.label}
                        </p>
                        <h3 className={`text-3xl font-mono font-bold ${kpi.color}`}>{formatCurrency(kpi.val)}</h3>
                        <div className="mt-6 w-full h-1 bg-gray-100 rounded-full overflow-hidden">
                            <div className={`h-full bg-blue-600 ${kpi.highlight ? 'w-full' : 'w-1/2'}`} />
                        </div>
                    </div>
                ))}
            </div>

            {/* GROUPED LIST */}
            <div className="space-y-6 max-w-[1500px] mx-auto">
                {groupedData.map(group => {
                    const isExpanded = expandedGroups.has(group.id);
                    return (
                        <div key={group.id} className={`bg-white border ${isExpanded ? 'border-blue-300 shadow-lg' : 'border-gray-200'} rounded-2xl overflow-hidden transition-all duration-500 shadow-sm`}>
                            <div onClick={() => toggleGroup(group.id)} className="p-8 flex flex-col md:flex-row items-center justify-between cursor-pointer hover:bg-gray-50 transition-all gap-8 relative">
                                <div className="flex items-center gap-6 w-full md:w-auto">
                                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-500 ${isExpanded ? 'bg-blue-600 text-white shadow-md' : 'bg-gray-100 text-gray-600 border border-gray-200'}`}>
                                        {groupBy === 'date' && <Calendar size={24} />}
                                        {groupBy === 'client' && <User size={24} />}
                                        {groupBy === 'batch' && <Package size={24} />}
                                    </div>
                                    <div>
                                        <h3 className="text-xl font-bold text-gray-900">{group.label}</h3>
                                        {groupBy === 'batch' && group.batch && (
                                            <div className="flex items-center gap-4 mt-1">
                                                <p className="text-sm text-gray-600 font-semibold">
                                                    Fornecedor: {group.supplier}
                                                </p>
                                                <span className="text-gray-300">•</span>
                                                <p className="text-sm text-gray-600 font-semibold">
                                                    Compra: {new Date(group.batch.data_recebimento).toLocaleDateString('pt-BR')}
                                                </p>
                                            </div>
                                        )}
                                        <p className="text-sm text-gray-600 font-semibold mt-1">{group.items.length} vendas</p>
                                    </div>
                                </div>

                                <div className="flex items-center gap-6 w-full md:w-auto justify-between md:justify-end flex-wrap">
                                    {groupBy === 'batch' && (
                                        <div className="text-right">
                                            <p className="text-xs text-gray-600 font-bold mb-1">Custo Total</p>
                                            <p className="font-mono font-bold text-gray-700">{formatCurrency(group.totalCost)}</p>
                                        </div>
                                    )}
                                    <div className="text-right">
                                        <p className="text-xs text-gray-600 font-bold mb-1">Receita</p>
                                        <p className="font-mono font-bold text-gray-900">{formatCurrency(group.totalRevenue)}</p>
                                    </div>
                                    <div className="text-right border-l border-gray-200 pl-6">
                                        <p className="text-xs text-gray-600 font-bold mb-1">Lucro</p>
                                        <p className={`font-mono font-bold ${group.totalProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>{formatCurrency(group.totalProfit)}</p>
                                    </div>
                                    <div className={`p-2 bg-gray-100 rounded-xl border border-gray-200 transition-all duration-500 ${isExpanded ? 'rotate-90 text-blue-600 scale-110 shadow-sm' : 'text-gray-400'}`}>
                                        <ChevronRight size={20} />
                                    </div>
                                </div>
                            </div>

                            {isExpanded && (
                                <div className="border-t border-gray-200 bg-gray-50 animate-fade-in">
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-left text-sm text-gray-700">
                                            <thead className="bg-gray-100 text-gray-700 font-bold text-xs">
                                                <tr>
                                                    <th className="px-10 py-6">Data</th>
                                                    <th className="px-10 py-6">Comprador</th>
                                                    <th className="px-10 py-6">Item</th>
                                                    <th className="px-10 py-6 text-right">Peso</th>
                                                    <th className="px-10 py-6 text-right">Valor Vendido</th>
                                                    <th className="px-10 py-6 text-right">Lucro</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-gray-200">
                                                {group.items.map((entry, idx) => (
                                                    <tr key={idx} className="hover:bg-blue-50 transition-colors">
                                                        <td className="px-10 py-6 font-mono text-gray-600 text-sm">{new Date(entry.sale.data_venda).toLocaleDateString()}</td>
                                                        <td className="px-10 py-6">
                                                            <div className="font-bold text-gray-900 text-sm">{entry.sale.nome_cliente || 'Varejo'}</div>
                                                        </td>
                                                        <td className="px-10 py-6">
                                                            <div className="text-xs font-mono text-gray-500 flex items-center gap-3">
                                                                <span className="bg-blue-50 border border-blue-200 px-2 py-0.5 rounded text-blue-700 font-semibold">{entry.item?.id_completo || 'N/A'}</span>
                                                                {entry.batch && groupBy !== 'batch' && <span className="text-gray-400">Lote: {entry.batch.id_lote}</span>}
                                                            </div>
                                                        </td>
                                                        <td className="px-10 py-6 text-right font-mono text-gray-700 font-semibold">{formatWeight(entry.sale.peso_real_saida)}</td>
                                                        <td className="px-10 py-6 text-right font-mono font-bold text-blue-700">{formatCurrency(entry.revenue)}</td>
                                                        <td className={`px-10 py-6 text-right font-mono font-bold ${entry.profit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                                                            {formatCurrency(entry.profit)}
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            )}
                        </div>
                    )
                })}
            </div>
        </div>
    );
};

export default SalesHistory;
