import React, { useState, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Clients from './components/Clients';
import Batches from './components/Batches';
import Stock from './components/Stock';
import Expedition from './components/Expedition';
import Financial from './components/Financial';
import SalesHistory from './components/SalesHistory';
import AIEditor from './components/AIEditor';
import Login from './components/Login';
import { AppState, Sale, PaymentMethod, StockItem, Batch } from './types';
import { MOCK_DATA } from './constants';
import { supabase } from './supabaseClient';
import { Cloud, CloudOff, Loader2, ShieldCheck, Activity } from 'lucide-react';

const App: React.FC = () => {
  const [session, setSession] = useState<any>(null);
  const [currentView, setCurrentView] = useState('menu');
  const [dbStatus, setDbStatus] = useState<'online' | 'offline' | 'checking'>('checking');
  const [data, setData] = useState<AppState>(MOCK_DATA);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchData = useCallback(async () => {
    if (!session) return;

    setDbStatus('checking');

    try {
      const [
        { data: clients, error: clientsError },
        { data: batches, error: batchesError },
        { data: stock, error: stockError },
        { data: sales, error: salesError },
        { data: transactions, error: transactionsError }
      ] = await Promise.all([
        supabase.from('clients').select('*').range(0, 9999),
        supabase.from('batches').select('*').range(0, 9999),
        supabase.from('stock_items').select('*').range(0, 9999),
        supabase.from('sales').select('*').range(0, 9999),
        supabase.from('transactions').select('*').range(0, 9999)
      ]);

      const clientsWithDebt = (clients || []).map(client => {
        const clientSales = (sales || []).filter(s => s.id_cliente === client.id_ferro && s.status_pagamento === 'PENDENTE');
        const totalDebt = clientSales.reduce((acc, sale) => {
          const total = sale.peso_real_saida * sale.preco_venda_kg;
          const paid = (sale as any).valor_pago || 0;
          return acc + (total - paid);
        }, 0);

        return { ...client, saldo_devedor: totalDebt };
      });

      setData({
        clients: clientsWithDebt || [],
        batches: batches || [],
        stock: stock || [],
        sales: sales || [],
        transactions: transactions || []
      });

      setDbStatus('online');
    } catch (e) {
      console.error(e);
      setDbStatus('offline');
    }
  }, [session]);

  useEffect(() => {
    fetchData();

    const channels = [
      supabase.channel('public:clients').on('postgres_changes', { event: '*', schema: 'public', table: 'clients' }, fetchData).subscribe(),
      supabase.channel('public:batches').on('postgres_changes', { event: '*', schema: 'public', table: 'batches' }, fetchData).subscribe(),
      supabase.channel('public:stock_items').on('postgres_changes', { event: '*', schema: 'public', table: 'stock_items' }, fetchData).subscribe(),
      supabase.channel('public:sales').on('postgres_changes', { event: '*', schema: 'public', table: 'sales' }, fetchData).subscribe(),
      supabase.channel('public:transactions').on('postgres_changes', { event: '*', schema: 'public', table: 'transactions' }, fetchData).subscribe(),
    ];

    return () => {
      channels.forEach(channel => supabase.removeChannel(channel));
    };
  }, [fetchData]);

  const sanitize = (val: any) => JSON.parse(JSON.stringify(val));

  const addBatch = async (batch: any): Promise<{ success: boolean; error?: string }> => {
    const cleanBatch = { ...batch };
    delete cleanBatch.pagamento_a_vista;
    delete cleanBatch.forma_pagamento;

    cleanBatch.peso_total_romaneio = parseFloat(cleanBatch.peso_total_romaneio) || 0;
    cleanBatch.valor_compra_total = parseFloat(cleanBatch.valor_compra_total) || 0;
    cleanBatch.frete = parseFloat(cleanBatch.frete) || 0;
    cleanBatch.gastos_extras = parseFloat(cleanBatch.gastos_extras) || 0;
    cleanBatch.custo_real_kg = parseFloat(cleanBatch.custo_real_kg) || 0;

    const { error } = await supabase.from('batches').insert(cleanBatch);
    if (error) return { success: false, error: error.message };
    await fetchData();
    return { success: true };
  };

  const deleteBatch = async (id: string) => {
    await supabase.from('batches').delete().eq('id_lote', id);
    fetchData();
  };

  const addStockItem = async (item: any) => {
    const cleanItem = sanitize(item);
    const { error } = await supabase.from('stock_items').insert(cleanItem);
    if (error) return { success: false, error: error.message };
    fetchData();
    return { success: true };
  };

  const updateStockItem = async (id: string, updates: Partial<StockItem>) => {
    await supabase.from('stock_items').update(sanitize(updates)).eq('id_completo', id);
    fetchData();
  };

  const addTransaction = async (transaction: any) => {
    await supabase.from('transactions').insert(sanitize(transaction));
    fetchData();
  };

  const registerBatchFinancial = async (batch: Batch) => {
    const totalCost = (batch.valor_compra_total || 0) + (batch.frete || 0) + (batch.gastos_extras || 0);
    if (totalCost === 0) return;

    const transactionData = {
      id: `LOTE-${batch.id_lote}-${Date.now()}`,
      data: batch.data_recebimento,
      descricao: `Compra Lote ${batch.id_lote} - ${batch.fornecedor}`,
      tipo: 'SAIDA',
      categoria: 'COMPRA_GADO',
      valor: totalCost,
      metodo_pagamento: (batch as any).forma_pagamento || 'OUTROS',
      referencia_id: batch.id_lote
    };

    if ((batch as any).pagamento_a_vista === true) {
      await addTransaction(transactionData);
    }
  };

  const addSales = async (newSales: Sale[]): Promise<{ success: boolean; error?: string }> => {
    const cleanSales = sanitize(newSales);
    try {
      const { error: salesError } = await supabase.from('sales').insert(cleanSales);
      if (salesError) return { success: false, error: salesError.message };

      const updatePromises = cleanSales.map((sale: Sale) =>
        supabase.from('stock_items').update({ status: 'VENDIDO' }).eq('id_completo', sale.id_completo)
      );
      await Promise.all(updatePromises);

      fetchData();
      return { success: true };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  };

  const removeStockItem = async (id_completo: string) => {
    await supabase.from('stock_items').delete().eq('id_completo', id_completo);
    fetchData();
  };

  const updateSaleCost = async (id_venda: string, newCost: number) => {
    await supabase.from('sales').update({ custo_extras_total: newCost }).eq('id_venda', id_venda);
    fetchData();
  };

  const deleteTransaction = async (id: string) => {
    await supabase.from('transactions').delete().eq('id', id);
    fetchData();
  };

  const addPartialPayment = async (saleId: string, valorPagamento: number, method: PaymentMethod, date: string) => {
    const sale = data.sales.find(s => s.id_venda === saleId);
    if (!sale) return;

    const valorTotal = sale.peso_real_saida * sale.preco_venda_kg;
    const valorPagoAtual = (sale as any).valor_pago || 0;
    const novoValorPago = valorPagoAtual + valorPagamento;
    const status = novoValorPago >= valorTotal ? 'PAGO' : 'PENDENTE';

    const { error: saleError } = await supabase.from('sales').update({
      valor_pago: novoValorPago,
      status_pagamento: status,
      forma_pagamento: method
    }).eq('id_venda', saleId);

    if (saleError) return;

    const transaction = {
      id: `TR-PARC-${saleId}-${Date.now()}`,
      data: date,
      descricao: `Pagamento ${novoValorPago >= valorTotal ? 'Final' : 'Parcial'} - ${sale.nome_cliente || 'Cliente'} - ${sale.id_completo}`,
      tipo: 'ENTRADA',
      categoria: 'VENDA',
      valor: valorPagamento,
      referencia_id: saleId,
      metodo_pagamento: method
    };

    await addTransaction(transaction);
    fetchData();
  };

  const receiveClientPayment = async (clientId: string, amount: number, method: PaymentMethod, date: string) => {
    const pendingSales = data.sales
      .filter(s => s.id_cliente === clientId && s.status_pagamento === 'PENDENTE')
      .sort((a, b) => new Date(a.data_venda).getTime() - new Date(b.data_venda).getTime());

    let remaining = amount;
    let count = 0;

    for (const sale of pendingSales) {
      if (remaining <= 0.01) break;
      const total = sale.peso_real_saida * sale.preco_venda_kg;
      const pago = (sale as any).valor_pago || 0;
      const devendo = total - pago;
      const pagarNesta = Math.min(devendo, remaining);

      if (pagarNesta > 0) {
        await addPartialPayment(sale.id_venda, pagarNesta, method, date);
        remaining -= pagarNesta;
        count++;
      }
    }

    if (count > 0) fetchData();
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setCurrentView('menu');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="text-blue-600 animate-spin" size={48} />
      </div>
    );
  }

  if (!session) {
    return <Login onLoginSuccess={() => { }} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans overflow-x-hidden selection:bg-blue-200">
      {currentView === 'menu' && <Sidebar setView={setCurrentView} onLogout={handleLogout} />}
      {currentView === 'dashboard' && <Dashboard sales={data.sales} stock={data.stock} transactions={data.transactions} onBack={() => setCurrentView('menu')} />}
      {currentView === 'clients' && <Clients clients={data.clients} addClient={async (c) => { await supabase.from('clients').insert(sanitize(c)); fetchData(); }} deleteClient={async (id) => { await supabase.from('clients').delete().eq('id_ferro', id); fetchData(); }} receiveClientPayment={receiveClientPayment} onBack={() => setCurrentView('menu')} />}
      {currentView === 'batches' && <Batches batches={data.batches} stock={data.stock} addBatch={addBatch} deleteBatch={deleteBatch} addStockItem={addStockItem} updateStockItem={updateStockItem} removeStockItem={removeStockItem} registerBatchFinancial={registerBatchFinancial} onGoToStock={() => setCurrentView('stock')} onBack={() => setCurrentView('menu')} />}
      {currentView === 'stock' && <Stock stock={data.stock} batches={data.batches} sales={data.sales} clients={data.clients} onBack={() => setCurrentView('menu')} />}
      {currentView === 'expedition' && <Expedition clients={data.clients} stock={data.stock} salesHistory={data.sales} onConfirmSale={(data) => {
        const { client, items, pricePerKg, extrasCost } = data;
        const newSales: Sale[] = items.map((item: StockItem) => ({
          id_venda: `V-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          id_cliente: client.id_ferro,
          nome_cliente: client.nome_social,
          id_completo: item.id_completo,
          peso_real_saida: item.peso_entrada,
          preco_venda_kg: pricePerKg,
          data_venda: new Date().toISOString().split('T')[0],
          quebra_kg: 0,
          lucro_liquido_unitario: 0,
          custo_extras_total: extrasCost / items.length,
          prazo_dias: 30,
          data_vencimento: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          forma_pagamento: 'OUTROS',
          status_pagamento: 'PENDENTE'
        }));
        addSales(newSales);
        setCurrentView('sales_history');
      }} onBack={() => setCurrentView('menu')} />}
      {currentView === 'sales_history' && <SalesHistory stock={data.stock} batches={data.batches} sales={data.sales} clients={data.clients} onBack={() => setCurrentView('menu')} />}
      {currentView === 'financial' && <Financial sales={data.sales} batches={data.batches} stock={data.stock} clients={data.clients} transactions={data.transactions} updateSaleCost={updateSaleCost} addTransaction={addTransaction} deleteTransaction={deleteTransaction} addPartialPayment={addPartialPayment} onBack={() => setCurrentView('menu')} />}
      {currentView === 'aistudio' && <AIEditor onBack={() => setCurrentView('menu')} />}

      {/* Connection Bar */}
      <div className="fixed bottom-4 left-4 z-[100] flex flex-wrap gap-2 pointer-events-none">
        {dbStatus === 'online' && (
          <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-3 py-1.5 rounded-full text-[10px] font-black uppercase backdrop-blur-md flex items-center gap-2 animate-fade-in shadow-lg">
            <Cloud size={12} className="animate-pulse" /> Sincronizado
          </div>
        )}
        {dbStatus === 'offline' && (
          <div className="bg-rose-500/10 border border-rose-500/20 text-rose-500 px-3 py-1.5 rounded-full text-[10px] font-black uppercase backdrop-blur-md flex items-center gap-2 animate-fade-in shadow-lg">
            <CloudOff size={12} /> Desconectado
          </div>
        )}
        {dbStatus === 'checking' && (
          <div className="bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 px-3 py-1.5 rounded-full text-[10px] font-black uppercase backdrop-blur-md flex items-center gap-2 animate-fade-in shadow-lg">
            <Loader2 size={12} className="animate-spin" /> Conectando
          </div>
        )}
        <div className="bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase backdrop-blur-md flex items-center gap-2 shadow-sm">
          <Activity size={12} className="text-blue-600" /> V2.0 LIGHT
        </div>
      </div>
    </div>
  );
};

export default App;
