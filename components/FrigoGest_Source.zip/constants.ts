import { AppState, StockType, Transaction } from './types';

export const CURRENT_DATE = '2026-01-12';

// Helper para gerar transações iniciais baseadas nos lotes mockados
const initialBatches = [
  {
    id_lote: 'L001',
    fornecedor: 'FAZENDA SANTA FÉ',
    data_recebimento: '2026-01-02',
    peso_total_romaneio: 1000,
    valor_compra_total: 20000,
    frete: 500,
    gastos_extras: 100,
    custo_real_kg: 20.60
  },
  {
    id_lote: '24', // From PDF
    fornecedor: 'TIAGO PORTO OLIVEIRA',
    data_recebimento: '2026-01-07',
    peso_total_romaneio: 2494.00,
    valor_compra_total: 58194.50, // Estimated based on market price
    frete: 0,
    gastos_extras: 0,
    custo_real_kg: 23.33
  }
];

const initialTransactions: Transaction[] = initialBatches.map(b => ({
  id: `TR-${b.id_lote}`,
  data: b.data_recebimento,
  descricao: `Compra Lote ${b.id_lote} (${b.fornecedor})`,
  tipo: 'SAIDA',
  categoria: 'COMPRA_GADO',
  valor: b.valor_compra_total + b.frete + b.gastos_extras,
  referencia_id: b.id_lote,
  metodo_pagamento: 'TRANSFERENCIA'
}));

// Adicionando algumas despesas operacionais fictícias para exemplo
initialTransactions.push({
  id: 'TR-LUZ-01',
  data: '2026-01-05',
  descricao: 'Conta de Energia (Câmara Fria)',
  tipo: 'SAIDA',
  categoria: 'OPERACIONAL',
  valor: 1250.00,
  metodo_pagamento: 'BOLETO'
});

export const MOCK_DATA: AppState = {
  clients: [
    {
      id_ferro: '77',
      nome_social: 'AÇOUGUE CENTRAL',
      whatsapp: '11999999999',
      limite_credito: 50000,
      saldo_devedor: 1200,
      endereco: 'Rua das Flores, 123',
      bairro: 'Centro',
      cidade: 'São Paulo',
      observacoes: 'Recebe apenas pela manhã.'
    },
    {
      id_ferro: '102',
      nome_social: 'MERCADO DO JOÃO',
      whatsapp: '11988888888',
      limite_credito: 25000,
      saldo_devedor: 0,
      endereco: 'Av. Paulista, 1000',
      bairro: 'Bela Vista',
      cidade: 'São Paulo',
      observacoes: ''
    },
    {
      id_ferro: '15',
      nome_social: 'CHURRASCARIA BOI DE OURO',
      whatsapp: '11977777777',
      limite_credito: 100000,
      saldo_devedor: 15400,
      endereco: 'Rodovia BR 116, km 50',
      bairro: 'Industrial',
      cidade: 'Guarulhos',
      observacoes: 'Cliente VIP. Entregar na porta dos fundos.'
    },
  ],
  batches: initialBatches,
  stock: [
    // L001 Items (Old)
    { id_completo: 'L001-01-INTEIRO', id_lote: 'L001', sequencia: 1, tipo: StockType.INTEIRO, peso_entrada: 280.5, status: 'DISPONIVEL', data_entrada: '2026-01-02' },
    { id_completo: 'L001-02-BANDA_A', id_lote: 'L001', sequencia: 2, tipo: StockType.BANDA_A, peso_entrada: 135.0, status: 'DISPONIVEL', data_entrada: '2026-01-02' },
    { id_completo: 'L001-02-BANDA_B', id_lote: 'L001', sequencia: 2, tipo: StockType.BANDA_B, peso_entrada: 134.5, status: 'DISPONIVEL', data_entrada: '2026-01-02' },

    // Lote 24 Items (From PDF)
    // Animal 1
    { id_completo: '24-01-BANDA_A', id_lote: '24', sequencia: 1, tipo: StockType.BANDA_A, peso_entrada: 148.70, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    { id_completo: '24-01-BANDA_B', id_lote: '24', sequencia: 1, tipo: StockType.BANDA_B, peso_entrada: 145.90, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    // Animal 2
    { id_completo: '24-02-BANDA_A', id_lote: '24', sequencia: 2, tipo: StockType.BANDA_A, peso_entrada: 140.10, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    { id_completo: '24-02-BANDA_B', id_lote: '24', sequencia: 2, tipo: StockType.BANDA_B, peso_entrada: 140.50, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    // Animal 3
    { id_completo: '24-03-BANDA_A', id_lote: '24', sequencia: 3, tipo: StockType.BANDA_A, peso_entrada: 119.30, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    { id_completo: '24-03-BANDA_B', id_lote: '24', sequencia: 3, tipo: StockType.BANDA_B, peso_entrada: 119.30, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    // Animal 4
    { id_completo: '24-04-BANDA_A', id_lote: '24', sequencia: 4, tipo: StockType.BANDA_A, peso_entrada: 123.90, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    { id_completo: '24-04-BANDA_B', id_lote: '24', sequencia: 4, tipo: StockType.BANDA_B, peso_entrada: 125.90, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    // Animal 5
    { id_completo: '24-05-BANDA_A', id_lote: '24', sequencia: 5, tipo: StockType.BANDA_A, peso_entrada: 118.10, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    { id_completo: '24-05-BANDA_B', id_lote: '24', sequencia: 5, tipo: StockType.BANDA_B, peso_entrada: 120.10, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    // Animal 6
    { id_completo: '24-06-BANDA_A', id_lote: '24', sequencia: 6, tipo: StockType.BANDA_A, peso_entrada: 149.30, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    { id_completo: '24-06-BANDA_B', id_lote: '24', sequencia: 6, tipo: StockType.BANDA_B, peso_entrada: 150.90, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    // Animal 7
    { id_completo: '24-07-BANDA_A', id_lote: '24', sequencia: 7, tipo: StockType.BANDA_A, peso_entrada: 115.70, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    { id_completo: '24-07-BANDA_B', id_lote: '24', sequencia: 7, tipo: StockType.BANDA_B, peso_entrada: 118.10, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    // Animal 8
    { id_completo: '24-08-BANDA_A', id_lote: '24', sequencia: 8, tipo: StockType.BANDA_A, peso_entrada: 118.30, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    { id_completo: '24-08-BANDA_B', id_lote: '24', sequencia: 8, tipo: StockType.BANDA_B, peso_entrada: 117.50, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    // Animal 9
    { id_completo: '24-09-BANDA_A', id_lote: '24', sequencia: 9, tipo: StockType.BANDA_A, peso_entrada: 110.10, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    { id_completo: '24-09-BANDA_B', id_lote: '24', sequencia: 9, tipo: StockType.BANDA_B, peso_entrada: 107.70, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    // Animal 10
    { id_completo: '24-10-BANDA_A', id_lote: '24', sequencia: 10, tipo: StockType.BANDA_A, peso_entrada: 118.10, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
    { id_completo: '24-10-BANDA_B', id_lote: '24', sequencia: 10, tipo: StockType.BANDA_B, peso_entrada: 116.50, status: 'DISPONIVEL', data_entrada: '2026-01-07' },
  ],
  sales: [],
  transactions: initialTransactions
};

export const getTypeName = (type: StockType) => {
  switch (type) {
    case StockType.INTEIRO: return 'Carcaça Inteira';
    case StockType.BANDA_A: return 'Banda A (Dir)';
    case StockType.BANDA_B: return 'Banda B (Esq)';
    default: return 'Desconhecido';
  }
};