import React, { useState } from 'react';
import { Sale, Batch, StockItem, Client } from '../types';
import { formatCurrency, formatWeight } from '../utils/helpers';
import { Edit2, Save, X, DollarSign, TrendingUp, TrendingDown } from 'lucide-react';

interface SalesReportsProps {
  sales: Sale[];
  batches: Batch[];
  stock: StockItem[];
  clients: Client[];
  updateSaleCost: (id_venda: string, newCost: number) => void;
}

const SalesReports: React.FC<SalesReportsProps> = ({ sales, batches, stock, clients, updateSaleCost }) => {
  const [editingSaleId, setEditingSaleId] = useState<string | null>(null);
  const [tempCost, setTempCost] = useState<string>('');

  // Helper to get full details for a sale
  const getSaleDetails = (sale: Sale) => {
    // Find item to find batch
    const item = stock.find(s => s.id_completo === sale.id_completo);
    const batch = item ? batches.find(b => b.id_lote === item.id_lote) : null;
    const client = clients.find(c => c.id_ferro === sale.id_cliente);

    const revenue = sale.peso_real_saida * sale.preco_venda_kg;
    const costKg = batch ? batch.custo_real_kg : 0;
    const cgs = sale.peso_real_saida * costKg; // Cost of Goods Sold
    const operationalCost = sale.custo_extras_total || 0;
    const netProfit = revenue - cgs - operationalCost;

    return {
      clientName: client ? client.nome_social : 'Desconhecido',
      revenue,
      cgs,
      operationalCost,
      netProfit,
      costKg
    };
  };

  const startEditing = (sale: Sale) => {
    setEditingSaleId(sale.id_venda);
    setTempCost(sale.custo_extras_total?.toString() || '0');
  };

  const saveCost = (id_venda: string) => {
    const val = parseFloat(tempCost);
    if (!isNaN(val)) {
      updateSaleCost(id_venda, val);
    }
    setEditingSaleId(null);
  };

  // Totals
  const totals = sales.reduce((acc, sale) => {
    const details = getSaleDetails(sale);
    return {
      revenue: acc.revenue + details.revenue,
      cgs: acc.cgs + details.cgs,
      ops: acc.ops + details.operationalCost,
      profit: acc.profit + details.netProfit
    };
  }, { revenue: 0, cgs: 0, ops: 0, profit: 0 });

  return (
    <div className="p-8 h-full bg-gray-50 overflow-y-auto text-gray-900">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Relatório de Vendas e Lucros</h2>
          <p className="text-gray-600">Análise financeira detalhada e lançamento de custos operacionais</p>
        </div>
      </div>

      {/* Financial Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <p className="text-xs text-gray-600 font-bold mb-1">Receita Bruta</p>
          <p className="text-2xl font-mono font-bold text-blue-600">{formatCurrency(totals.revenue)}</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <p className="text-xs text-gray-600 font-bold mb-1">Custo Mercadoria (CMV)</p>
          <p className="text-2xl font-mono font-bold text-gray-700">{formatCurrency(totals.cgs)}</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <p className="text-xs text-gray-600 font-bold mb-1">Despesas Extras</p>
          <p className="text-2xl font-mono font-bold text-amber-600">{formatCurrency(totals.ops)}</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm relative overflow-hidden">
          <div className="absolute right-0 top-0 p-4 opacity-10">
            {totals.profit >= 0 ? <TrendingUp size={48} /> : <TrendingDown size={48} />}
          </div>
          <p className="text-xs text-emerald-600 font-bold mb-1">Lucro Líquido Real</p>
          <p className={`text-2xl font-mono font-bold ${totals.profit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
            {formatCurrency(totals.profit)}
          </p>
        </div>
      </div>

      {/* Detailed Table */}
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-left text-sm text-gray-700">
          <thead className="bg-gray-50 text-gray-700 font-semibold text-xs">
            <tr>
              <th className="px-6 py-4">Data</th>
              <th className="px-6 py-4">Cliente / Peça</th>
              <th className="px-6 py-4 text-right">Venda Total</th>
              <th className="px-6 py-4 text-right">Custo (Lote)</th>
              <th className="px-6 py-4 text-right w-48 bg-blue-50 border-x border-blue-200">Despesas Extras</th>
              <th className="px-6 py-4 text-right">Lucro Líquido</th>
              <th className="px-6 py-4 text-center">Ação</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {sales.map(sale => {
              const details = getSaleDetails(sale);
              const isEditing = editingSaleId === sale.id_venda;

              return (
                <tr key={sale.id_venda} className="hover:bg-blue-50 transition-colors">
                  <td className="px-6 py-4 font-mono">
                    {new Date(sale.data_venda).toLocaleDateString('pt-BR')}
                    <div className="text-xs text-gray-500">{sale.id_venda}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-bold text-gray-900">{details.clientName}</div>
                    <div className="font-mono text-xs text-gray-500">{sale.id_completo} ({formatWeight(sale.peso_real_saida)})</div>
                  </td>
                  <td className="px-6 py-4 text-right font-mono text-blue-700">
                    {formatCurrency(details.revenue)}
                  </td>
                  <td className="px-6 py-4 text-right font-mono text-gray-600">
                    {formatCurrency(details.cgs)}
                    <div className="text-xs">({formatCurrency(details.costKg)}/kg)</div>
                  </td>

                  {/* Editable Column */}
                  <td className="px-6 py-4 text-right bg-blue-50 border-x border-blue-200">
                    {isEditing ? (
                      <div className="flex items-center gap-1 justify-end">
                        <input
                          autoFocus
                          type="number"
                          step="0.01"
                          className="w-24 bg-white border border-blue-500 rounded px-2 py-1 text-right text-gray-900 outline-none"
                          value={tempCost}
                          onChange={e => setTempCost(e.target.value)}
                          onKeyDown={e => e.key === 'Enter' && saveCost(sale.id_venda)}
                        />
                      </div>
                    ) : (
                      <span className={`font-mono ${details.operationalCost > 0 ? 'text-amber-600' : 'text-gray-400'}`}>
                        {formatCurrency(details.operationalCost)}
                      </span>
                    )}
                  </td>

                  <td className="px-6 py-4 text-right font-mono font-bold">
                    <span className={details.netProfit >= 0 ? 'text-emerald-600' : 'text-red-600'}>
                      {formatCurrency(details.netProfit)}
                    </span>
                  </td>

                  <td className="px-6 py-4 text-center">
                    {isEditing ? (
                      <div className="flex justify-center gap-2">
                        <button onClick={() => saveCost(sale.id_venda)} className="p-1 bg-emerald-600 text-white rounded hover:bg-emerald-700">
                          <Save size={16} />
                        </button>
                        <button onClick={() => setEditingSaleId(null)} className="p-1 bg-gray-400 text-white rounded hover:bg-gray-500">
                          <X size={16} />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => startEditing(sale)}
                        className="text-gray-500 hover:text-blue-600 transition-colors flex items-center justify-center gap-1 text-xs mx-auto px-2 py-1 rounded hover:bg-gray-100"
                      >
                        <Edit2 size={14} /> Editar
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
            {sales.length === 0 && (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                  Nenhuma venda registrada para calcular lucros.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SalesReports;