import React, { useState } from 'react';
import { Client, PaymentMethod } from '../types';
import { Search, UserPlus, CreditCard, ArrowDownLeft, X, CheckCircle, Wallet, ArrowLeft, MapPin, Phone, Building2, StickyNote, ExternalLink, User, ChevronRight, Contact, Trash2, Calendar, DollarSign, PenTool, Zap, Activity, ShieldCheck } from 'lucide-react';
import { formatCurrency } from '../utils/helpers';

interface ClientsProps {
  clients: Client[];
  addClient: (c: Client) => void;
  deleteClient: (id: string) => void;
  receiveClientPayment: (clientId: string, amount: number, method: PaymentMethod, date: string) => void;
  onBack: () => void;
}

const Clients: React.FC<ClientsProps> = ({ clients, addClient, deleteClient, receiveClientPayment, onBack }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newClient, setNewClient] = useState<Partial<Client>>({
    id_ferro: '',
    nome_social: '',
    whatsapp: '',
    endereco: '',
    bairro: '',
    cidade: '',
    observacoes: '',
    limite_credito: 0,
    saldo_devedor: 0
  });

  const [selectedClientForDetails, setSelectedClientForDetails] = useState<Client | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('PIX');

  const filteredClients = clients.filter(c =>
    c.id_ferro.includes(searchTerm) ||
    c.nome_social.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmitNewClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (newClient.id_ferro && newClient.nome_social) {
      addClient(newClient as Client);
      setShowAddForm(false);
      setNewClient({ id_ferro: '', nome_social: '', whatsapp: '', endereco: '', bairro: '', cidade: '', observacoes: '', limite_credito: 0, saldo_devedor: 0 });
    }
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedClientForDetails && paymentAmount) {
      const amount = parseFloat(paymentAmount);
      if (amount > 0) {
        receiveClientPayment(selectedClientForDetails.id_ferro, amount, paymentMethod, paymentDate);
        setShowPaymentModal(false);
        setPaymentAmount('');
        setPaymentMethod('PIX');
        setSelectedClientForDetails(null);
      }
    }
  };

  const getGoogleMapsLink = (client: Client) => {
    if (!client.endereco) return null;
    const query = encodeURIComponent(`${client.endereco}, ${client.bairro || ''}, ${client.cidade || ''}`);
    return `https://www.google.com/maps/search/?api=1&query=${query}`;
  };

  const getWhatsAppLink = (phone: string) => {
    const cleanPhone = phone.replace(/\D/g, '');
    return `https://wa.me/55${cleanPhone}`;
  }

  return (
    <div className="p-4 md:p-6 min-h-screen bg-gray-50 text-gray-900 relative pb-20 font-sans animate-fade-in selection:bg-blue-200">

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <button onClick={onBack} className="text-white bg-blue-600 hover:bg-blue-700 p-3 rounded-xl border border-blue-700 transition-all hover:shadow-md active:scale-95 flex items-center gap-2 mb-4">
            <ArrowLeft size={20} />
            <span className="font-bold text-sm">Voltar</span>
          </button>
          <div className="flex items-center gap-4">
            <div className="bg-white p-3 rounded-2xl border border-gray-200 shadow-sm">
              <Contact size={24} className="text-blue-600" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Clientes</h1>
              <p className="text-gray-500 text-sm font-semibold mt-1">Agenda de contatos</p>
            </div>
          </div>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl flex items-center gap-2 transition-all font-bold text-sm shadow-md active:scale-95"
        >
          <UserPlus size={18} /> Novo Cliente
        </button>
      </div>

      {showAddForm && (
        <div className="mb-10 bg-slate-900/80 backdrop-blur-xl p-10 rounded-[2.5rem] border border-white/5 animate-fade-in shadow-2xl relative overflow-hidden group">
          <h3 className="text-lg font-black mb-8 text-white flex items-center gap-3 italic uppercase tracking-tighter">
            <div className="w-1.5 h-6 bg-indigo-500 rounded-full" /> New Operator Registration
          </h3>
          <form onSubmit={handleSubmitNewClient} className="space-y-8 relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
              <div className="md:col-span-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">FERRO_ID</label>
                <div className="bg-slate-950 border border-slate-800 rounded-2xl flex items-center px-4 focus-within:ring-2 focus-within:ring-indigo-600 transition-all shadow-inner">
                  <span className="text-indigo-500 font-mono font-black">#</span>
                  <input required type="text" className="w-full bg-transparent p-5 text-white focus:outline-none font-black text-xl font-mono uppercase" placeholder="77" value={newClient.id_ferro} onChange={e => setNewClient({ ...newClient, id_ferro: e.target.value.toUpperCase() })} />
                </div>
              </div>
              <div className="md:col-span-6">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Social Name / Entity</label>
                <input required type="text" className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-5 text-white focus:ring-2 focus:ring-indigo-600 outline-none font-bold placeholder-slate-800 transition-all shadow-inner" placeholder="EX: CENTRAL_STATION_CO" value={newClient.nome_social} onChange={e => setNewClient({ ...newClient, nome_social: e.target.value.toUpperCase() })} />
              </div>
              <div className="md:col-span-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Contact_Num</label>
                <input type="text" className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-5 text-white focus:ring-2 focus:ring-indigo-600 outline-none font-mono font-bold placeholder-slate-800 shadow-inner" placeholder="119..." value={newClient.whatsapp} onChange={e => setNewClient({ ...newClient, whatsapp: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-4 border-t border-white/5">
              <div className="md:col-span-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Base_Address</label>
                <input type="text" className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-slate-300 outline-none focus:ring-1 focus:ring-indigo-500 shadow-inner" value={newClient.endereco} onChange={e => setNewClient({ ...newClient, endereco: e.target.value })} />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">Credit_Limit (R$)</label>
                <input type="number" className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-emerald-400 font-mono font-black border-l-4 border-l-emerald-600 outline-none shadow-inner" value={newClient.limite_credito} onChange={e => setNewClient({ ...newClient, limite_credito: Number(e.target.value) })} />
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-6 border-t border-white/5">
              <button type="button" onClick={() => setShowAddForm(false)} className="px-8 py-4 rounded-xl text-slate-500 font-black text-[10px] uppercase tracking-widest hover:text-white transition-colors">Abort</button>
              <button type="submit" className="bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 px-12 rounded-2xl transition-all shadow-xl text-xs uppercase tracking-widest border-b-4 border-indigo-800 active:scale-95">Commit Registry</button>
            </div>
          </form>
        </div>
      )}

      {/* SEARCH BOX */}
      <div className="relative mb-8 max-w-2xl mx-auto">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
        <input
          type="text"
          placeholder="Buscar por nome ou ID..."
          className="w-full bg-white border border-gray-300 rounded-xl py-3 pl-12 pr-4 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 outline-none shadow-sm text-sm font-medium"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* COMPACT GRID - AGENDA STYLE */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 max-w-7xl mx-auto">
        {filteredClients.map(client => (
          <div key={client.id_ferro} onClick={() => setSelectedClientForDetails(client)} className="group relative bg-white border border-gray-200 rounded-xl p-3 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between">
            <div className="flex justify-between items-start mb-2">
              <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700 font-mono font-bold text-sm group-hover:bg-blue-600 group-hover:text-white transition-all">{client.id_ferro}</div>
              {client.saldo_devedor > 0 && <div className="bg-rose-50 text-rose-600 text-[9px] font-bold px-2 py-0.5 rounded-full border border-rose-200 flex items-center gap-1"><Activity size={8} /> Pendente</div>}
            </div>
            <h3 className="text-sm font-bold text-gray-900 mb-1 leading-tight truncate group-hover:text-blue-600 transition-colors">{client.nome_social}</h3>
            <p className="text-[10px] text-gray-500 font-semibold flex items-center gap-1 mb-2"><MapPin size={10} /> {client.cidade || 'N/A'}</p>
            <div className="pt-2 border-t border-gray-200 flex justify-between items-center">
              <div>
                <p className="text-[9px] text-gray-500 font-bold uppercase">Saldo</p>
                <p className={`font-mono text-sm font-bold ${client.saldo_devedor > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>{formatCurrency(client.saldo_devedor)}</p>
              </div>
              <div className="bg-gray-100 p-1.5 rounded-lg text-gray-400 group-hover:bg-blue-600 group-hover:text-white transition-all"><ChevronRight size={14} /></div>
            </div>
          </div>
        ))}
      </div>

      {selectedClientForDetails && !showPaymentModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-2xl animate-fade-in">
          <div className="bg-slate-900 border border-white/10 w-full max-w-2xl rounded-[3rem] shadow-[0_50px_100px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col max-h-[90vh] relative">
            <div className="bg-slate-950/50 p-10 flex justify-between items-start border-b border-white/5 relative">
              <div className="absolute top-0 right-0 p-10 opacity-[0.03] text-indigo-500 pointer-events-none"><Contact size={250} /></div>
              <div className="flex gap-8 relative z-10">
                <div className="w-24 h-24 bg-slate-900 rounded-[2rem] flex items-center justify-center text-indigo-500 font-mono font-black text-4xl shadow-2xl border border-slate-800 rotate-3">{selectedClientForDetails.id_ferro}</div>
                <div className="flex flex-col justify-center">
                  <p className="text-[10px] bg-slate-800 text-slate-500 font-black px-3 py-1 rounded-full uppercase tracking-widest w-fit mb-2 italic">Account: Locked_Registry</p>
                  <h2 className="text-3xl md:text-5xl font-black text-white italic uppercase tracking-tighter leading-none">{selectedClientForDetails.nome_social}</h2>
                </div>
              </div>
              <button onClick={() => setSelectedClientForDetails(null)} className="absolute top-6 right-6 text-slate-500 hover:text-white bg-slate-800 p-3 rounded-2xl transition-all shadow-xl"><X size={24} /></button>
            </div>
            <div className="p-10 overflow-y-auto space-y-10 custom-scrollbar">
              <div className="grid grid-cols-2 gap-8">
                <div className="bg-slate-950 p-8 rounded-[2rem] border border-slate-800 shadow-inner">
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em] mb-3 flex items-center gap-2"><ShieldCheck size={14} className="text-emerald-500" /> Credit_Line</p>
                  <p className="text-3xl font-mono text-white font-black">{formatCurrency(selectedClientForDetails.limite_credito)}</p>
                </div>
                <div className="bg-slate-950 p-8 rounded-[2rem] border border-slate-800 shadow-inner">
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em] mb-3 flex items-center gap-2"><Activity size={14} className="text-rose-500" /> Exposure_Sum</p>
                  <p className={`text-3xl font-mono font-black ${selectedClientForDetails.saldo_devedor > 0 ? 'text-rose-500' : 'text-slate-600'}`}>{formatCurrency(selectedClientForDetails.saldo_devedor)}</p>
                </div>
              </div>
              <div className="space-y-6">
                <h4 className="text-[10px] font-black text-slate-700 uppercase tracking-[0.5em] flex items-center gap-4"><div className="w-6 h-[1px] bg-indigo-500" /> Core_Data_Feed</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-slate-950 p-6 rounded-[2rem] border border-slate-800 flex flex-col justify-between h-44 hover:border-indigo-500/20 transition-all group cursor-default">
                    <Phone size={24} className="text-indigo-500 opacity-20 group-hover:opacity-100 transition-opacity" />
                    <div>
                      <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">WhatsApp_Comms</p>
                      <a href={getWhatsAppLink(selectedClientForDetails.whatsapp)} target="_blank" className="text-2xl font-black text-white hover:text-indigo-400 transition-colors">{selectedClientForDetails.whatsapp}</a>
                    </div>
                  </div>
                  <div className="bg-slate-950 p-6 rounded-[2rem] border border-slate-800 h-44 hover:border-indigo-500/20 transition-all group flex flex-col justify-between">
                    <div className="flex justify-between items-start">
                      <MapPin size={24} className="text-indigo-500 opacity-20 group-hover:opacity-100 transition-opacity" />
                      <a href={getGoogleMapsLink(selectedClientForDetails) || '#'} target="_blank" className="text-[8px] font-black text-indigo-400 uppercase tracking-widest bg-indigo-500/10 px-3 py-1.5 rounded-lg border border-indigo-500/20">Open_GIS</a>
                    </div>
                    <div>
                      <p className="text-sm font-black text-slate-300 uppercase leading-snug truncate">{selectedClientForDetails.endereco}</p>
                      <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-1 italic">{selectedClientForDetails.bairro} &bull; {selectedClientForDetails.cidade}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-8 bg-slate-950 border-t border-white/5 flex gap-4 justify-between items-center">
              <button onClick={() => { deleteClient(selectedClientForDetails.id_ferro); setSelectedClientForDetails(null); }} className="w-14 h-14 rounded-2xl border border-rose-500/20 text-rose-500 flex items-center justify-center hover:bg-rose-500/10 transition-all shadow-xl"><Trash2 size={24} /></button>
              <div className="flex gap-4">
                <button onClick={() => setSelectedClientForDetails(null)} className="px-8 py-5 rounded-2xl text-slate-500 font-black text-[10px] uppercase tracking-widest hover:text-white transition-colors">Close_Task</button>
                <button onClick={() => { setShowPaymentModal(true); setPaymentAmount(''); }} disabled={selectedClientForDetails.saldo_devedor <= 0} className="bg-indigo-600 disabled:opacity-50 hover:bg-indigo-500 text-white px-12 py-5 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-2xl shadow-indigo-900/40 active:scale-95 border-b-4 border-indigo-800 flex items-center gap-3">
                  <Wallet size={20} /> EXECUTE_SETTLEMENT
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showPaymentModal && selectedClientForDetails && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/98 backdrop-blur-3xl animate-fade-in">
          <div className="bg-slate-900 border border-white/10 w-full max-w-md rounded-[3rem] shadow-2xl p-10 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-[4px] bg-gradient-to-r from-transparent via-emerald-500 to-transparent opacity-50 shadow-[0_0_20px_rgba(16,185,129,0.3)]"></div>
            <div className="flex justify-between items-center mb-10">
              <h3 className="text-2xl font-black text-white flex items-center gap-4 italic uppercase tracking-tighter"><div className="w-1.5 h-6 bg-emerald-500 rounded-full" /> Financial Settlement</h3>
              <button onClick={() => setShowPaymentModal(false)} className="text-slate-500 hover:text-white bg-slate-800 p-2.5 rounded-2xl transition-all"><X size={20} /></button>
            </div>
            <div className="bg-slate-950 p-6 rounded-3xl border border-slate-800 flex justify-between items-center shadow-inner mb-8">
              <div>
                <p className="text-[8px] text-slate-500 font-black uppercase tracking-widest mb-1">Exposure_Val</p>
                <p className="text-2xl font-mono font-black text-rose-500">{formatCurrency(selectedClientForDetails.saldo_devedor)}</p>
              </div>
              <div className="h-10 w-[1px] bg-slate-800" />
              <div className="text-right">
                <p className="text-[8px] text-slate-500 font-black uppercase tracking-widest mb-1">Identity</p>
                <p className="text-sm font-black text-white italic truncate max-w-[150px] uppercase">#{selectedClientForDetails.id_ferro}</p>
              </div>
            </div>
            <form onSubmit={handlePaymentSubmit} className="space-y-8">
              <div className="space-y-3">
                <label className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em] ml-1 uppercase">Input Settlement Amount</label>
                <input autoFocus required type="number" step="0.01" className="w-full bg-slate-950 border border-slate-800 rounded-[2.5rem] p-8 text-white text-5xl font-mono font-black text-center focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all shadow-inner tracking-tighter" placeholder="0.00" value={paymentAmount} onChange={e => setPaymentAmount(e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <input type="date" className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white font-black text-xs outline-none" value={paymentDate} onChange={e => setPaymentDate(e.target.value)} />
                <select className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white font-black text-xs h-[48px] outline-none" value={paymentMethod} onChange={e => setPaymentMethod(e.target.value as any)}>
                  <option value="PIX">PIX</option>
                  <option value="DINHEIRO">CASH</option>
                  <option value="TRANSFERENCIA">TRANSF</option>
                </select>
              </div>
              <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-6 rounded-2xl shadow-xl shadow-emerald-900/30 text-[10px] uppercase tracking-[0.5em] active:scale-[0.98] transition-all border-b-4 border-emerald-800 flex items-center justify-center gap-4 uppercase"><ShieldCheck size={20} /> COMMIT_VAL_DEBT</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Clients;