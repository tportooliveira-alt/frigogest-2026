import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import { Lock, Mail, Loader2, Truck, ShieldAlert, Activity } from 'lucide-react';

interface LoginProps {
  onLoginSuccess: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (error) setError(null);
  }, [email, password]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    try {
      const { data, error: authError } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password: cleanPassword,
      });

      if (authError) {
        if (authError.message.includes("Invalid login credentials") || authError.status === 400) {
          setError("Credenciais inválidas. Verifique usuário e senha.");
        } else {
          setError(authError.message);
        }
      } else if (data.session) {
        onLoginSuccess();
      }
    } catch (err: any) {
      setError("Falha de conexão com o servidor.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center p-4 selection:bg-blue-200 font-sans">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, rgb(59, 130, 246) 1px, transparent 0)', backgroundSize: '30px 30px' }} />

      <div className="bg-white border border-gray-200 w-full max-w-md rounded-3xl shadow-xl overflow-hidden p-10 relative">
        <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-transparent via-blue-600 to-transparent shadow-lg"></div>

        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-50 rounded-3xl shadow-md border border-blue-200 mb-6 hover:scale-110 transition-transform">
            <Truck size={38} className="text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900">Frigo<span className="text-blue-600">Gest</span></h1>
          <div className="flex items-center justify-center gap-2 mt-2">
            <div className="h-[1px] w-6 bg-gray-300" />
            <p className="text-gray-500 text-xs font-semibold">Sistema de Gestão 2026</p>
            <div className="h-[1px] w-6 bg-gray-300" />
          </div>
        </div>

        {error && (
          <div className="mb-6 bg-rose-50 border border-rose-200 text-rose-700 px-5 py-4 rounded-2xl text-sm font-semibold flex items-start gap-3 animate-fade-in">
            <ShieldAlert size={18} className="shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-700 ml-1">E-mail</label>
            <div className="relative group">
              <input
                type="email"
                required
                className="w-full bg-gray-50 border border-gray-300 rounded-2xl p-4 pl-12 text-gray-900 focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-gray-400 shadow-sm"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="usuario@frigogest.com"
              />
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-600 transition-colors" size={20} />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-700 ml-1">Senha</label>
            <div className="relative group">
              <input
                type="password"
                required
                className="w-full bg-gray-50 border border-gray-300 rounded-2xl p-4 pl-12 text-gray-900 focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-gray-400 shadow-sm"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-600 transition-colors" size={20} />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white font-bold py-5 rounded-2xl transition-all flex items-center justify-center gap-3 disabled:opacity-50 text-sm mt-4 shadow-lg"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : (
              <>
                <Activity size={18} />
                Entrar no Sistema
              </>
            )}
          </button>
        </form>

        <div className="mt-10 pt-6 border-t border-gray-200 text-center">
          <p className="text-xs text-gray-500 font-semibold">
            © FrigoGest 2026 - Todos os direitos reservados
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;