import React, { useState, useMemo } from 'react';
import { Sale, Batch, StockItem, Client, Transaction, PaymentMethod } from '../types';
import { formatCurrency, formatWeight } from '../utils/helpers';
import { Edit2, Save, X, DollarSign, TrendingUp, TrendingDown, PlusCircle, ArrowUpRight, ArrowDownLeft, FileText, PieChart, CalendarClock, CheckCircle, ArrowLeft, Beef, Tag, Wallet, ShoppingBag, Truck, Landmark, Printer, Calendar, Filter, Trash2 } from 'lucide-react';
import { getTypeName } from '../constants';
import { jsPDF } from "jspdf";

interface FinancialProps {
    sales: Sale[];
    batches: Batch[];
    stock: StockItem[];
    clients: Client[];
    transactions: Transaction[];
    updateSaleCost: (id_venda: string, newCost: number) => void;
    addTransaction: (t: Transaction) => void;
    deleteTransaction: (id: string) => void;
    addPartialPayment: (saleId: string, valorPagamento: number, method: PaymentMethod, date: string) => void;
    onBack: () => void;
}

const Financial: React.FC<FinancialProps> = ({ sales, batches, stock, clients, transactions, updateSaleCost, addTransaction, deleteTransaction, addPartialPayment, onBack }) => {

    // Prova de Vida da Versão Nova
    React.useEffect(() => {
        console.log("Financial Component Mounted - Version 2.0");
        // alert("VERSÃO NOVA CARREGADA COM SUCESSO! 🚀"); // Comentado para não irritar, mas o console vai mostrar
    }, []);

    const [activeTab, setActiveTab] = useState<'cashflow' | 'receivables' | 'profit'>('cashflow');
    const [showTransactionForm, setShowTransactionForm] = useState(false);

    // --- STATE DE FILTROS ---
    const [filterStartDate, setFilterStartDate] = useState(() => {
        const date = new Date();
        date.setDate(1); // Primeiro dia do mês atual
        return date.toISOString().split('T')[0];
    });
    const [filterEndDate, setFilterEndDate] = useState(() => {
        return new Date().toISOString().split('T')[0]; // Hoje
    });

    const [newTransaction, setNewTransaction] = useState<Partial<Transaction>>({
        descricao: '',
        valor: 0,
        tipo: 'SAIDA',
        categoria: 'OPERACIONAL',
        data: new Date().toISOString().split('T')[0]
    });
    /* Refatorado para evitar conflitos de cache: saleToPay ao invés de receivingSale */
    const [saleToPay, setSaleToPay] = useState<Sale | null>(null);
    const [receiveDate, setReceiveDate] = useState(new Date().toISOString().split('T')[0]);
    const [receiveMethod, setReceiveMethod] = useState<PaymentMethod>('PIX');
    const [partialPaymentAmount, setPartialPaymentAmount] = useState<string>('');

    const openTransactionForm = (tipo: 'ENTRADA' | 'SAIDA') => {
        setNewTransaction({
            descricao: '',
            valor: 0,
            tipo,
            categoria: tipo === 'SAIDA' ? 'OPERACIONAL' : 'VENDA',
            data: new Date().toISOString().split('T')[0]
        });
        setShowTransactionForm(true);
    };

    // Helper de Saldo
    const getSaleBalance = (sale: Sale) => {
        const valorTotal = sale.peso_real_saida * sale.preco_venda_kg;
        const valorPago = (sale as any).valor_pago || 0;
        const saldoDevedor = valorTotal - valorPago;
        return { valorTotal, valorPago, saldoDevedor };
    };

    const confirmPartialPayment = () => {
        console.log("Clique em confirmar:", { saleToPay, partialPaymentAmount });

        if (!saleToPay) return;

        if (!partialPaymentAmount) {
            alert("⚠️ Digite um valor para o pagamento!");
            return;
        }

        const valor = parseFloat(partialPaymentAmount.replace(',', '.'));
        const { saldoDevedor } = getSaleBalance(saleToPay);

        console.log("Valores processados:", { valor, saldoDevedor });

        if (isNaN(valor) || valor <= 0) {
            alert("⚠️ Valor inválido! Digite um número maior que zero.");
            return;
        }

        // Pequena tolerância para erros de ponto flutuante (R$ 0.01)
        if (valor > saldoDevedor + 0.01) {
            alert(`⚠️ O valor digitado (${formatCurrency(valor)}) é maior que o saldo devedor (${formatCurrency(saldoDevedor)})!`);
            return;
        }

        try {
            addPartialPayment(saleToPay.id_venda, valor, receiveMethod, receiveDate);
            setSaleToPay(null);
            setPartialPaymentAmount('');
            alert("✅ Pagamento registrado com sucesso!");
        } catch (error) {
            console.error("Erro ao processar pagamento:", error);
            alert("❌ Erro ao salvar pagamento. Veja o console para detalhes.");
        }
    };

    // FILTRAGEM DE TRANSAÇÕES
    const filteredTransactions = useMemo(() => {
        return transactions.filter(t => {
            return t.data >= filterStartDate && t.data <= filterEndDate;
        }).sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime());
    }, [transactions, filterStartDate, filterEndDate]);

    // Agrupamento por Data para o Extrato (usando as filtradas)
    const transactionsByDate = useMemo(() => {
        const groups: Record<string, Transaction[]> = {};
        filteredTransactions.forEach(t => {
            if (!groups[t.data]) groups[t.data] = [];
            groups[t.data].push(t);
        });
        return groups;
    }, [filteredTransactions]);

    // Cálculos baseados no FILTRO (Saldo do Período)
    const periodInflow = filteredTransactions.filter(t => t.tipo === 'ENTRADA').reduce((acc, t) => acc + t.valor, 0);
    const periodOutflow = filteredTransactions.filter(t => t.tipo === 'SAIDA').reduce((acc, t) => acc + t.valor, 0);
    const periodBalance = periodInflow - periodOutflow;

    // Saldo Total Geral (Independente do filtro, para mostrar caixa atual real)
    const totalBalanceGlobal = transactions.filter(t => t.tipo === 'ENTRADA').reduce((acc, t) => acc + t.valor, 0) -
        transactions.filter(t => t.tipo === 'SAIDA').reduce((acc, t) => acc + t.valor, 0);

    const handleTransactionSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newTransaction.descricao && newTransaction.valor) {
            addTransaction({
                id: `TR-MANUAL-${Date.now()}`,
                data: newTransaction.data!,
                descricao: newTransaction.descricao,
                tipo: newTransaction.tipo as 'ENTRADA' | 'SAIDA',
                categoria: newTransaction.categoria as any,
                valor: Number(newTransaction.valor),
                metodo_pagamento: 'OUTROS'
            });
            setShowTransactionForm(false);
            setNewTransaction({ descricao: '', valor: 0, tipo: 'SAIDA', categoria: 'OPERACIONAL', data: new Date().toISOString().split('T')[0] });
        }
    };

    const pendingSales = sales
        .filter(s => {
            const isPaid = (transactions || []).some(t => t.referencia_id === s.id_venda);
            return ((s as any).valor_pago || 0) < (s.peso_real_saida * s.preco_venda_kg) && !isPaid; // Considera pendente se valor pago < total OU se não tem transação full
        })
        .sort((a, b) => new Date(a.data_vencimento).getTime() - new Date(b.data_vencimento).getTime());

    const totalReceivable = pendingSales.reduce((acc, s) => {
        const valorTotal = s.peso_real_saida * s.preco_venda_kg;
        const valorPago = (s as any).valor_pago || 0;
        return acc + (valorTotal - valorPago);
    }, 0);



    const [editingSaleId, setEditingSaleId] = useState<string | null>(null);
    const [tempCost, setTempCost] = useState<string>('');

    const getSaleDetails = (sale: Sale) => {
        const item = stock.find(s => s.id_completo === sale.id_completo);
        const batch = item ? batches.find(b => b.id_lote === item.id_lote) : null;
        const client = clients.find(c => c.id_ferro === sale.id_cliente);

        const revenue = sale.peso_real_saida * sale.preco_venda_kg;
        const costKg = batch ? batch.custo_real_kg : 0;
        const cgs = sale.peso_real_saida * costKg;
        const operationalCost = sale.custo_extras_total || 0;
        const netProfit = revenue - cgs - operationalCost;

        return { clientName: client ? client.nome_social : 'Desconhecido', revenue, cgs, operationalCost, netProfit, costKg };
    };

    const startEditing = (sale: Sale) => {
        setEditingSaleId(sale.id_venda);
        setTempCost(sale.custo_extras_total?.toString() || '0');
    };

    const saveCost = (id_venda: string) => {
        const val = parseFloat(tempCost);
        if (!isNaN(val)) updateSaleCost(id_venda, val);
        setEditingSaleId(null);
    };

    const profitTotals = sales.reduce((acc, sale) => {
        const details = getSaleDetails(sale);
        return {
            revenue: acc.revenue + details.revenue,
            cgs: acc.cgs + details.cgs,
            ops: acc.ops + details.operationalCost,
            profit: acc.profit + details.netProfit
        };
    }, { revenue: 0, cgs: 0, ops: 0, profit: 0 });

    // Helper para ícones do extrato
    const getTransactionIcon = (t: Transaction) => {
        if (t.categoria === 'VENDA') return <DollarSign size={16} />;
        if (t.categoria === 'COMPRA_GADO') return <Beef size={16} />;
        if (t.categoria === 'OPERACIONAL') return <Truck size={16} />;
        if (t.categoria === 'ADMINISTRATIVO') return <Landmark size={16} />;
        return <FileText size={16} />;
    };

    // Helper para cor do ícone
    const getIconColor = (t: Transaction) => {
        if (t.tipo === 'ENTRADA') return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
        return 'bg-red-500/10 text-red-500 border-red-500/20';
    };

    // --- FILTROS RÁPIDOS ---
    const setFilterToday = () => {
        const today = new Date().toISOString().split('T')[0];
        setFilterStartDate(today);
        setFilterEndDate(today);
    };

    const setFilterWeek = () => {
        const today = new Date();
        const lastWeek = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
        setFilterEndDate(today.toISOString().split('T')[0]);
        setFilterStartDate(lastWeek.toISOString().split('T')[0]);
    };

    const setFilterMonth = () => {
        const date = new Date();
        const y = date.getFullYear(), m = date.getMonth();
        const firstDay = new Date(y, m, 1);
        const lastDay = new Date(y, m + 1, 0);
        setFilterStartDate(firstDay.toISOString().split('T')[0]);
        setFilterEndDate(lastDay.toISOString().split('T')[0]);
    };

    // --- GERAÇÃO DE PDF FINANCEIRO ---
    const generateFinancialPDF = () => {
        const doc = new jsPDF();
        const now = new Date();

        // Cabeçalho
        doc.setFont("courier", "bold");
        doc.setFontSize(18);
        doc.text("RELATÓRIO FINANCEIRO (EXTRATO)", 105, 20, { align: "center" });

        doc.setFontSize(10);
        doc.setFont("courier", "normal");
        doc.text(`Gerado em: ${now.toLocaleDateString('pt-BR')} ${now.toLocaleTimeString('pt-BR')}`, 105, 26, { align: "center" });
        doc.text(`Período: ${new Date(filterStartDate).toLocaleDateString('pt-BR')} até ${new Date(filterEndDate).toLocaleDateString('pt-BR')}`, 105, 31, { align: "center" });

        // Resumo do Período
        doc.setLineWidth(0.5);
        doc.line(10, 35, 200, 35);

        doc.setFontSize(12);
        doc.setFont("courier", "bold");
        doc.text("RESUMO DO PERÍODO SELECIONADO", 10, 43);

        doc.setFontSize(10);
        doc.setFont("courier", "normal");
        doc.text(`(+) Entradas: ${formatCurrency(periodInflow)}`, 10, 50);
        doc.text(`(-) Saídas:   ${formatCurrency(periodOutflow)}`, 10, 56);
        doc.setFont("courier", "bold");
        doc.text(`(=) Resultado:${formatCurrency(periodBalance)}`, 10, 62);

        doc.line(10, 68, 200, 68);

        // Tabela de Transações
        doc.setFontSize(12);
        doc.text("DETALHAMENTO DAS MOVIMENTAÇÕES", 10, 76);

        let y = 85;
        doc.setFontSize(9);
        doc.setFont("courier", "bold");

        // Header Tabela
        doc.text("DATA", 10, y);
        doc.text("DESCRIÇÃO", 40, y);
        doc.text("CATEGORIA", 120, y);
        doc.text("VALOR", 170, y);

        y += 2;
        doc.line(10, y, 200, y);
        y += 5;

        doc.setFont("courier", "normal");

        // Loop Transações
        filteredTransactions.forEach((t) => {
            // Verificar quebra de página
            if (y > 280) {
                doc.addPage();
                y = 20;
                doc.text("(Continuação...)", 10, y);
                y += 10;
            }

            const dateStr = new Date(t.data).toLocaleDateString('pt-BR');
            const descStr = t.descricao.length > 35 ? t.descricao.substring(0, 35) + "..." : t.descricao;
            const catStr = t.categoria.substring(0, 15);
            const valStr = formatCurrency(t.valor);
            const isEntry = t.tipo === 'ENTRADA';

            doc.text(dateStr, 10, y);
            doc.text(descStr, 40, y);
            doc.text(catStr, 120, y);

            if (isEntry) {
                doc.setTextColor(0, 150, 0); // Verde para entrada (opcional, jsPDF básico pode não suportar cor bem em todas impressoras, mas ajuda na tela)
            } else {
                doc.setTextColor(200, 0, 0); // Vermelho para saída
            }
            doc.text((isEntry ? "+" : "-") + valStr, 195, y, { align: "right" });
            doc.setTextColor(0, 0, 0); // Reset cor

            y += 5;
        });

        // Rodapé
        const pageCount = doc.internal.pages.length - 1;
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(8);
            doc.text(`Página ${i} de ${pageCount} - FrigoGest 2026`, 105, 290, { align: "center" });
        }

        doc.save(`Extrato_${filterStartDate}_${filterEndDate}.pdf`);
    };

    return (
        // Alterado: min-h-screen, removed overflow-y-auto, adjusted padding
        <div className="p-4 md:p-8 min-h-screen bg-slate-950 text-slate-200 animate-fade-in pb-20">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                <div>
                    <button onClick={onBack} className="text-slate-400 hover:text-white flex items-center gap-2 mb-2 text-sm font-medium transition-colors">
                        <ArrowLeft size={16} /> Voltar ao Menu
                    </button>
                    <h2 className="text-2xl md:text-3xl font-bold text-white">Financeiro</h2>
                    <p className="text-slate-400 text-sm md:text-base">Fluxo de Caixa e Resultados</p>
                </div>

                <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800 w-full md:w-auto overflow-x-auto shadow-lg">
                    <button
                        onClick={() => setActiveTab('cashflow')}
                        className={`flex-1 md:flex-none px-6 py-2 rounded-md text-sm font-bold transition-all flex items-center justify-center gap-2 whitespace-nowrap ${activeTab === 'cashflow' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                            }`}
                    >
                        <Wallet size={18} />
                        Extrato
                    </button>
                    <button
                        onClick={() => setActiveTab('receivables')}
                        className={`flex-1 md:flex-none px-6 py-2 rounded-md text-sm font-bold transition-all flex items-center justify-center gap-2 whitespace-nowrap ${activeTab === 'receivables' ? 'bg-amber-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                            }`}
                    >
                        <CalendarClock size={18} />
                        A Receber {pendingSales.length > 0 && <span className="bg-white text-amber-600 px-1.5 rounded-full text-[10px] font-bold h-4 flex items-center justify-center">{pendingSales.length}</span>}
                    </button>
                    <button
                        onClick={() => setActiveTab('profit')}
                        className={`flex-1 md:flex-none px-6 py-2 rounded-md text-sm font-bold transition-all flex items-center justify-center gap-2 whitespace-nowrap ${activeTab === 'profit' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
                            }`}
                    >
                        <PieChart size={18} />
                        DRE
                    </button>
                </div>
            </div>

            {activeTab === 'cashflow' && (
                <div className="animate-fade-in max-w-4xl mx-auto">

                    {/* BARRA DE FILTROS E RELATÓRIO */}
                    <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl mb-6 shadow-lg">
                        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                            <div className="flex items-center gap-2 text-slate-400 text-sm font-bold uppercase w-full md:w-auto">
                                <Filter size={16} /> Filtros:
                            </div>

                            <div className="flex items-center gap-2 flex-1 w-full md:w-auto overflow-x-auto">
                                <input
                                    type="date"
                                    className="bg-slate-950 border border-slate-700 rounded-lg p-2 text-white text-sm outline-none focus:ring-1 focus:ring-blue-500"
                                    value={filterStartDate}
                                    onChange={e => setFilterStartDate(e.target.value)}
                                />
                                <span className="text-slate-500">-</span>
                                <input
                                    type="date"
                                    className="bg-slate-950 border border-slate-700 rounded-lg p-2 text-white text-sm outline-none focus:ring-1 focus:ring-blue-500"
                                    value={filterEndDate}
                                    onChange={e => setFilterEndDate(e.target.value)}
                                />
                            </div>

                            <div className="flex gap-2 w-full md:w-auto">
                                <button onClick={setFilterToday} className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition-colors">Hoje</button>
                                <button onClick={setFilterWeek} className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition-colors">7 Dias</button>
                                <button onClick={setFilterMonth} className="px-3 py-1.5 rounded bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition-colors">Este Mês</button>
                            </div>

                            <div className="flex gap-2 w-full md:w-auto">
                                <button
                                    onClick={generateFinancialPDF}
                                    className="bg-slate-100 text-slate-900 hover:bg-white px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 shadow-md flex-1 md:flex-none justify-center"
                                >
                                    <FileText size={16} /> Gerar PDF
                                </button>
                                <button
                                    onClick={() => window.print()}
                                    className="bg-blue-600 text-white hover:bg-blue-500 px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 shadow-md flex-1 md:flex-none justify-center"
                                >
                                    <Printer size={16} /> Imprimir
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* DASHBOARD BANCÁRIO (Resumo) */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">

                        {/* Saldo - Destaque */}
                        <div className={`md:col-span-1 bg-gradient-to-br from-slate-900 to-slate-900 border ${totalBalanceGlobal >= 0 ? 'border-blue-500/40' : 'border-red-500/40'} p-6 rounded-2xl shadow-xl relative overflow-hidden group`}>
                            <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                                <Landmark size={80} />
                            </div>
                            <p className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-2">Saldo Atual (Geral)</p>
                            <div className="flex items-baseline gap-1">
                                <span className="text-slate-400 font-mono text-lg">R$</span>
                                <span className={`text-3xl font-mono font-bold tracking-tight ${totalBalanceGlobal >= 0 ? 'text-white' : 'text-red-400'}`}>
                                    {new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2 }).format(totalBalanceGlobal)}
                                </span>
                            </div>
                            <div className="mt-4 flex gap-2">
                                <button
                                    onClick={() => openTransactionForm('ENTRADA')}
                                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-black py-2.5 rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-lg active:scale-95 uppercase"
                                >
                                    <ArrowUpRight size={14} /> Entrada
                                </button>
                                <button
                                    onClick={() => openTransactionForm('SAIDA')}
                                    className="flex-1 bg-red-600 hover:bg-red-500 text-white text-[10px] font-black py-2.5 rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-lg active:scale-95 uppercase"
                                >
                                    <ArrowDownLeft size={14} /> Gasto
                                </button>
                            </div>
                        </div>

                        {/* Entradas e Saídas (FILTRADAS) */}
                        <div className="md:col-span-2 grid grid-cols-2 gap-4">
                            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm relative">
                                <div className="flex justify-between items-start mb-2">
                                    <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-500 border border-emerald-500/20">
                                        <ArrowUpRight size={16} />
                                    </div>
                                    <span className="text-[10px] bg-slate-950 px-2 py-0.5 rounded text-slate-500 border border-slate-800">No Período</span>
                                </div>
                                <p className="text-[10px] text-slate-500 uppercase font-bold">Entradas</p>
                                <p className="text-xl font-mono font-bold text-emerald-400">{formatCurrency(periodInflow)}</p>
                            </div>
                            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm relative">
                                <div className="flex justify-between items-start mb-2">
                                    <div className="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 border border-red-500/20">
                                        <ArrowDownLeft size={16} />
                                    </div>
                                    <span className="text-[10px] bg-slate-950 px-2 py-0.5 rounded text-slate-500 border border-slate-800">No Período</span>
                                </div>
                                <p className="text-[10px] text-slate-500 uppercase font-bold">Saídas</p>
                                <p className="text-xl font-mono font-bold text-red-400">{formatCurrency(periodOutflow)}</p>
                            </div>
                        </div>
                    </div>

                    {/* Transaction Form Modal */}
                    {showTransactionForm && (
                        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
                            <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl p-6">
                                <div className="flex justify-between items-center mb-6 border-b border-slate-800 pb-4">
                                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                        <PlusCircle className="text-blue-500" /> Nova Movimentação
                                    </h3>
                                    <button onClick={() => setShowTransactionForm(false)} className="text-slate-400 hover:text-white bg-slate-800 p-2 rounded-full"><X size={20} /></button>
                                </div>
                                <form onSubmit={handleTransactionSubmit} className="space-y-5">
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="text-xs font-bold text-slate-500 uppercase mb-1.5 block">Tipo</label>
                                            <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
                                                <button
                                                    type="button"
                                                    onClick={() => setNewTransaction({ ...newTransaction, tipo: 'ENTRADA' })}
                                                    className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${newTransaction.tipo === 'ENTRADA' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                                                >
                                                    ENTRADA
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={() => setNewTransaction({ ...newTransaction, tipo: 'SAIDA' })}
                                                    className={`flex-1 py-2 text-xs font-bold rounded-md transition-all ${newTransaction.tipo === 'SAIDA' ? 'bg-red-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                                                >
                                                    SAÍDA
                                                </button>
                                            </div>
                                        </div>
                                        <div>
                                            <label className="text-xs font-bold text-slate-500 uppercase mb-1.5 block">Data</label>
                                            <input type="date" required className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none" value={newTransaction.data} onChange={e => setNewTransaction({ ...newTransaction, data: e.target.value })} />
                                        </div>
                                    </div>

                                    <div>
                                        <label className="text-xs font-bold text-slate-500 uppercase mb-1.5 block">Descrição</label>
                                        <input type="text" required placeholder="Ex: Conta de Luz, Venda Balcão..." className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none" value={newTransaction.descricao} onChange={e => setNewTransaction({ ...newTransaction, descricao: e.target.value })} />
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="text-xs font-bold text-slate-500 uppercase mb-1.5 block">Categoria</label>
                                            <select className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none" value={newTransaction.categoria} onChange={e => setNewTransaction({ ...newTransaction, categoria: e.target.value as any })}>
                                                <option value="OPERACIONAL">Operacional</option>
                                                <option value="ADMINISTRATIVO">Administrativo</option>
                                                <option value="COMPRA_GADO">Compra de Gado</option>
                                                <option value="VENDA">Venda</option>
                                                <option value="OUTROS">Outros</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label className="text-xs font-bold text-slate-500 uppercase mb-1.5 block">Valor (R$)</label>
                                            <div className="relative">
                                                <span className="absolute left-3 top-3 text-slate-500">R$</span>
                                                <input type="number" step="0.01" required placeholder="0.00" className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 pl-9 text-white font-mono font-bold focus:ring-2 focus:ring-blue-500 outline-none" value={newTransaction.valor || ''} onChange={e => setNewTransaction({ ...newTransaction, valor: parseFloat(e.target.value) })} />
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-900/40 mt-2 flex items-center justify-center gap-2">
                                        <CheckCircle size={20} /> Salvar Lançamento
                                    </button>
                                </form>
                            </div>
                        </div>
                    )}

                    {/* TIMELINE (Extrato Bancário) */}
                    <div className="space-y-6">
                        <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider pl-1 flex justify-between">
                            <span>Movimentações do Período</span>
                            <span className="text-xs font-normal text-slate-600">
                                {filteredTransactions.length} registros encontrados
                            </span>
                        </h3>

                        {Object.keys(transactionsByDate).length === 0 ? (
                            <div className="p-12 text-center text-slate-500 bg-slate-900 rounded-2xl border border-slate-800 border-dashed">
                                <FileText className="mx-auto mb-3 opacity-20" size={48} />
                                <p>Nenhuma transação encontrada neste período.</p>
                            </div>
                        ) : (
                            <div className="space-y-6">
                                {Object.keys(transactionsByDate).sort((a, b) => new Date(b).getTime() - new Date(a).getTime()).map(date => (
                                    <div key={date} className="relative">
                                        {/* Sticky Date Header */}
                                        <div className="sticky top-0 z-20 bg-slate-950/95 backdrop-blur-sm py-2 px-1 mb-2 border-b border-slate-800/50 flex items-center gap-2">
                                            <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                                            <span className="text-xs font-bold text-slate-300 uppercase tracking-wide">
                                                {new Date(date).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}
                                            </span>
                                        </div>

                                        {/* Transactions List Card */}
                                        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
                                            <div className="divide-y divide-slate-800">
                                                {transactionsByDate[date].map((t) => (
                                                    <div key={t.id} className="flex items-center justify-between p-4 hover:bg-slate-800/50 transition-colors group">
                                                        {/* Left: Icon & Info */}
                                                        <div className="flex items-center gap-4 overflow-hidden">
                                                            {/* Icon Circle */}
                                                            <div className={`w-12 h-12 rounded-full flex items-center justify-center border shrink-0 ${getIconColor(t)}`}>
                                                                {getTransactionIcon(t)}
                                                            </div>

                                                            {/* Texts */}
                                                            <div className="min-w-0">
                                                                <p className="text-sm font-bold text-slate-200 truncate pr-2">
                                                                    {t.descricao}
                                                                </p>
                                                                <div className="flex flex-wrap items-center gap-2 mt-0.5">
                                                                    <span className="text-[10px] font-bold uppercase text-slate-500 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                                                                        {t.categoria.replace('_', ' ')}
                                                                    </span>
                                                                    {t.metodo_pagamento && (
                                                                        <span className="text-[10px] text-slate-500 uppercase">{t.metodo_pagamento}</span>
                                                                    )}
                                                                    {t.referencia_id && (
                                                                        <span className="text-[10px] font-mono text-slate-600">#{t.referencia_id.split('-').pop()}</span>
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </div>

                                                        {/* Right: Value & Delete */}
                                                        <div className="flex items-center gap-4 pl-3 shrink-0">
                                                            <p className={`font-mono font-bold text-sm md:text-base ${t.tipo === 'ENTRADA' ? 'text-emerald-400' : 'text-red-400'}`}>
                                                                {t.tipo === 'ENTRADA' ? '+' : '-'} {formatCurrency(t.valor)}
                                                            </p>
                                                            <button
                                                                onClick={() => deleteTransaction(t.id)}
                                                                className="text-slate-600 hover:text-red-500 p-1 rounded-lg hover:bg-slate-800 transition-colors"
                                                                title="Apagar Lançamento"
                                                            >
                                                                <Trash2 size={16} />
                                                            </button>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            )}

            {activeTab === 'receivables' && (
                <div className="animate-fade-in mb-12">
                    {/* Summary */}
                    <div className="bg-gradient-to-r from-amber-900/40 to-slate-900 border border-amber-900/50 p-6 rounded-xl mb-6 flex flex-col md:flex-row justify-between items-center gap-4">
                        <div>
                            <p className="text-amber-400 font-medium mb-1 flex items-center gap-2">
                                <CalendarClock size={18} /> Total a Receber (Vendas Pendentes)
                            </p>
                            <h3 className="text-3xl font-bold text-white font-mono">{formatCurrency(totalReceivable)}</h3>
                            {sales.length > 0 && pendingSales.length === 0 && (
                                <p className="text-[10px] text-slate-500 mt-2 italic font-sans">
                                    Obs: {sales.length} vendas no total, mas nenhuma detectada como pendente.
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Pending Sales Table REFORMULATED (Mobile Scroll on Table only if needed, but page scroll preferred) */}
                    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl overflow-x-auto">
                        <table className="w-full text-left text-sm text-slate-400 min-w-[800px]">
                            <thead className="bg-slate-950 text-slate-200 uppercase font-medium text-xs">
                                <tr>
                                    <th className="px-4 py-4">Vencimento</th>
                                    <th className="px-4 py-4 w-1/4">Cliente</th>
                                    <th className="px-4 py-4 text-center bg-slate-800/30">Lote</th>
                                    <th className="px-4 py-4 text-center bg-slate-800/30">Seq</th>
                                    <th className="px-4 py-4 text-right">Peso (Kg)</th>
                                    <th className="px-4 py-4 text-right">Valor Total</th>
                                    <th className="px-4 py-4 text-center">Ação</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800">
                                {pendingSales.map(sale => {
                                    const client = clients.find(c => c.id_ferro === sale.id_cliente);
                                    const value = sale.peso_real_saida * sale.preco_venda_kg;
                                    const today = new Date().toISOString().split('T')[0];
                                    const isOverdue = sale.data_vencimento < today;

                                    // Parse ID Completo: LOTE-SEQ-TIPO (Ex: L2026-001-02-2)
                                    const parts = sale.id_completo.split('-');
                                    let loteId = parts[0];
                                    let seqId = parts[1];

                                    if (parts.length >= 4) {
                                        loteId = `${parts[0]}-${parts[1]}`;
                                        seqId = parts[2];
                                    } else if (parts.length === 3) {
                                        loteId = parts[0];
                                        seqId = parts[1];
                                    }

                                    return (
                                        <tr key={sale.id_venda} className="hover:bg-slate-800/50">
                                            <td className="px-4 py-4 font-mono">
                                                <span className={isOverdue ? 'text-red-400 font-bold' : 'text-slate-300'}>
                                                    {new Date(sale.data_vencimento).toLocaleDateString('pt-BR')}
                                                </span>
                                                {isOverdue && <span className="block text-[10px] text-red-500 font-bold uppercase">Atrasado</span>}
                                            </td>
                                            <td className="px-4 py-4">
                                                <div className="text-white font-bold text-lg">{sale.nome_cliente || client?.nome_social || 'Desconhecido'}</div>
                                                <div className="text-xs text-slate-500">Ferro #{sale.id_cliente}</div>
                                            </td>
                                            <td className="px-4 py-4 text-center bg-slate-800/20">
                                                <span className="font-mono text-blue-300 font-bold">{loteId}</span>
                                            </td>
                                            <td className="px-4 py-4 text-center bg-slate-800/20">
                                                <span className="font-mono text-white font-bold text-lg border border-slate-600 bg-slate-700 px-2 rounded">
                                                    {seqId}
                                                </span>
                                            </td>
                                            <td className="px-4 py-4 text-right font-mono text-slate-400">
                                                {formatWeight(sale.peso_real_saida)}
                                            </td>
                                            <td className="px-4 py-4 text-right font-mono text-lg font-bold">
                                                {(() => {
                                                    const { saldoDevedor } = getSaleBalance(sale);
                                                    return (
                                                        <div>
                                                            <div className="text-amber-400 font-black">{formatCurrency(saldoDevedor)}</div>
                                                            {(sale as any).valor_pago > 0 && (
                                                                <div className="text-[10px] text-emerald-400">
                                                                    Pago: {formatCurrency((sale as any).valor_pago)}
                                                                </div>
                                                            )}
                                                        </div>
                                                    );
                                                })()}
                                            </td>
                                            <td className="px-4 py-4 text-center">
                                                <button
                                                    onClick={() => {
                                                        setSaleToPay(sale);
                                                        setReceiveMethod(sale.forma_pagamento);
                                                    }}
                                                    className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 mx-auto transition-colors shadow-lg w-full max-w-[120px]"
                                                >
                                                    <CheckCircle size={16} /> BAIXAR
                                                </button>
                                            </td>
                                        </tr>
                                    );
                                })}
                                {pendingSales.length === 0 && (
                                    <tr><td colSpan={7} className="p-8 text-center text-slate-500">Nenhuma conta a receber pendente.</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>

                </div>
            )}

            {activeTab === 'profit' && (
                <div className="animate-fade-in mb-12">
                    {/* PROFIT VIEW (Original Sales Reports Logic) */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                        <div className="bg-slate-900 p-6 rounded-xl border border-slate-800">
                            <p className="text-xs text-slate-400 uppercase font-bold mb-1">Receita Vendas</p>
                            <p className="text-2xl font-mono font-bold text-blue-400">{formatCurrency(profitTotals.revenue)}</p>
                        </div>
                        <div className="bg-slate-900 p-6 rounded-xl border border-slate-800">
                            <p className="text-xs text-slate-400 uppercase font-bold mb-1">CMV (Custo Carne)</p>
                            <p className="text-2xl font-mono font-bold text-slate-300">{formatCurrency(profitTotals.cgs)}</p>
                        </div>
                        <div className="bg-slate-900 p-6 rounded-xl border border-slate-800">
                            <p className="text-xs text-slate-400 uppercase font-bold mb-1">Custos Venda</p>
                            <p className="text-2xl font-mono font-bold text-amber-500">{formatCurrency(profitTotals.ops)}</p>
                        </div>
                        <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 relative overflow-hidden">
                            <div className="absolute right-0 top-0 p-4 opacity-10">
                                {profitTotals.profit >= 0 ? <TrendingUp size={48} /> : <TrendingDown size={48} />}
                            </div>
                            <p className="text-xs text-emerald-400 uppercase font-bold mb-1">Lucro Vendas</p>
                            <p className={`text-2xl font-mono font-bold ${profitTotals.profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                {formatCurrency(profitTotals.profit)}
                            </p>
                        </div>
                    </div>

                    <div className="bg-blue-500/10 border border-blue-500/20 p-4 rounded-xl mb-6 flex items-center gap-3">
                        <DollarSign className="text-blue-400" size={24} />
                        <div>
                            <p className="text-blue-200 font-bold text-sm">Gerenciamento de Recebíveis</p>
                            <p className="text-blue-400/80 text-xs">Clique no botão <span className="text-emerald-400 font-bold">BAIXAR</span> para registrar pagamentos parciais ou totais. O saldo será atualizado automaticamente.</p>
                        </div>
                    </div>

                    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl overflow-x-auto">
                        <table className="w-full text-left text-sm text-slate-400 min-w-[900px]">
                            <thead className="bg-slate-950 text-slate-200 uppercase font-medium text-xs">
                                <tr>
                                    <th className="px-6 py-4">Data</th>
                                    <th className="px-6 py-4">Cliente / Peça</th>
                                    <th className="px-6 py-4 text-right">Venda Total</th>
                                    <th className="px-6 py-4 text-right">Custo (Lote)</th>
                                    <th className="px-6 py-4 text-right w-48 bg-slate-800/30 border-x border-slate-800">Custos Extras</th>
                                    <th className="px-6 py-4 text-right">Lucro Líquido</th>
                                    <th className="px-6 py-4 text-center">Ação</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800">
                                {sales.map(sale => {
                                    const details = getSaleDetails(sale);
                                    const isEditing = editingSaleId === sale.id_venda;
                                    return (
                                        <tr key={sale.id_venda} className="hover:bg-slate-800/50 transition-colors">
                                            <td className="px-6 py-4 font-mono">
                                                {new Date(sale.data_venda).toLocaleDateString('pt-BR')}
                                                <div className="text-[10px] text-slate-600">{sale.id_venda}</div>
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className="font-bold text-white">{details.clientName}</div>
                                                <div className="font-mono text-xs text-slate-500">{sale.id_completo} ({formatWeight(sale.peso_real_saida)})</div>
                                            </td>
                                            <td className="px-6 py-4 text-right font-mono text-blue-300">{formatCurrency(details.revenue)}</td>
                                            <td className="px-6 py-4 text-right font-mono text-slate-500">{formatCurrency(details.cgs)}</td>
                                            <td className="px-6 py-4 text-right bg-slate-800/30 border-x border-slate-800">
                                                {isEditing ? (
                                                    <div className="flex items-center gap-1 justify-end">
                                                        <input autoFocus type="number" step="0.01" className="w-24 bg-slate-950 border border-blue-500 rounded px-2 py-1 text-right text-white outline-none" value={tempCost} onChange={e => setTempCost(e.target.value)} onKeyDown={e => e.key === 'Enter' && saveCost(sale.id_venda)} />
                                                    </div>
                                                ) : (
                                                    <span className={`font-mono ${details.operationalCost > 0 ? 'text-amber-400' : 'text-slate-600'}`}>{formatCurrency(details.operationalCost)}</span>
                                                )}
                                            </td>
                                            <td className="px-6 py-4 text-right font-mono font-bold">
                                                <span className={details.netProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}>{formatCurrency(details.netProfit)}</span>
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                {isEditing ? (
                                                    <div className="flex justify-center gap-2">
                                                        <button onClick={() => saveCost(sale.id_venda)} className="p-1 bg-emerald-600 text-white rounded hover:bg-emerald-500"><Save size={16} /></button>
                                                        <button onClick={() => setEditingSaleId(null)} className="p-1 bg-slate-700 text-white rounded hover:bg-slate-600"><X size={16} /></button>
                                                    </div>
                                                ) : (
                                                    <button onClick={() => startEditing(sale)} className="text-slate-500 hover:text-blue-400 transition-colors flex items-center justify-center gap-1 text-xs mx-auto px-2 py-1 rounded hover:bg-slate-800"><Edit2 size={14} /> Editar</button>
                                                )}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* Modal de Pagamento Parcial (NOVO) */}
            {saleToPay && (
                <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
                    <div className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl max-w-md w-full p-6 animate-in zoom-in">
                        <h3 className="text-xl font-black text-white uppercase mb-4 flex items-center gap-2">
                            <DollarSign className="text-emerald-500" size={24} />
                            Registrar Pagamento
                        </h3>

                        {/* Versão Segura do Modal */}
                        <div className="space-y-4">
                            {(() => {
                                try {
                                    // Proteção contra dados nulos
                                    if (!saleToPay) return <div>Erro: Venda não encontrada.</div>;

                                    const valorTotal = (saleToPay.peso_real_saida || 0) * (saleToPay.preco_venda_kg || 0);
                                    const valorPago = (saleToPay as any).valor_pago || 0;
                                    const saldoDevedor = valorTotal - valorPago;

                                    return (
                                        <>
                                            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                                                <div className="flex justify-between items-center">
                                                    <span className="text-xs text-slate-500 uppercase font-bold">Cliente:</span>
                                                    <span className="text-sm text-white font-bold">{saleToPay.nome_cliente || 'Desconhecido'}</span>
                                                </div>
                                                <div className="flex justify-between items-center">
                                                    <span className="text-xs text-slate-500 uppercase font-bold">Peça:</span>
                                                    <span className="text-sm text-blue-400 font-mono">{saleToPay.id_completo}</span>
                                                </div>
                                                <div className="border-t border-slate-800 pt-2 mt-2">
                                                    <div className="flex justify-between items-center">
                                                        <span className="text-xs text-slate-500 uppercase font-bold">Valor Total:</span>
                                                        <span className="text-lg text-white font-mono font-bold">{formatCurrency(valorTotal)}</span>
                                                    </div>
                                                    <div className="flex justify-between items-center">
                                                        <span className="text-xs text-slate-500 uppercase font-bold">Já Pago:</span>
                                                        <span className="text-sm text-emerald-400 font-mono">{formatCurrency(valorPago)}</span>
                                                    </div>
                                                    <div className="flex justify-between items-center bg-amber-500/10 border border-amber-500/30 rounded-lg p-2 mt-2">
                                                        <span className="text-xs text-amber-400 uppercase font-black">Saldo Devedor:</span>
                                                        <span className="text-2xl text-amber-400 font-mono font-black">{formatCurrency(saldoDevedor)}</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div>
                                                <label className="text-xs font-black text-emerald-500 uppercase mb-2 block">Valor do Pagamento</label>
                                                <input
                                                    type="number"
                                                    step="0.01"
                                                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-4 text-3xl font-mono text-emerald-400 text-right outline-none focus:border-emerald-500 transition-all font-bold"
                                                    placeholder="0.00"
                                                    value={partialPaymentAmount}
                                                    onChange={e => setPartialPaymentAmount(e.target.value)}
                                                    autoFocus
                                                />
                                                <p className="text-xs text-slate-500 mt-1">Digitar valor para dar baixa parcial ou total.</p>
                                            </div>

                                            <div>
                                                <label className="text-xs font-black text-blue-500 uppercase mb-2 block">Método</label>
                                                <select
                                                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white outline-none focus:border-blue-500"
                                                    value={receiveMethod}
                                                    onChange={e => setReceiveMethod(e.target.value as PaymentMethod)}
                                                >
                                                    <option value="PIX">PIX</option>
                                                    <option value="DINHEIRO">Dinheiro</option>
                                                    <option value="TRANSFERENCIA">Transferência</option>
                                                    <option value="CHEQUE">Cheque</option>
                                                    <option value="BOLETO">Boleto</option>
                                                    <option value="OUTROS">Outros</option>
                                                </select>
                                            </div>

                                            <div>
                                                <label className="text-xs font-black text-blue-500 uppercase mb-2 block">Data</label>
                                                <input
                                                    type="date"
                                                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white outline-none focus:border-blue-500"
                                                    value={receiveDate}
                                                    onChange={e => setReceiveDate(e.target.value)}
                                                />
                                            </div>

                                            <div className="flex gap-2 pt-4">
                                                <button
                                                    onClick={() => {
                                                        setSaleToPay(null);
                                                        setPartialPaymentAmount('');
                                                    }}
                                                    className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-3 rounded-xl font-bold transition-all"
                                                >
                                                    Cancelar
                                                </button>
                                                <button
                                                    onClick={confirmPartialPayment}
                                                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-3 rounded-xl font-bold transition-all shadow-lg shadow-emerald-900/40 flex items-center justify-center gap-2"
                                                >
                                                    <CheckCircle size={20} />
                                                    Confirmar Baixa
                                                </button>
                                            </div>
                                        </>
                                    );
                                } catch (err: any) {
                                    return <div className="text-red-500 p-4">Erro ao renderizar modal: {err.message}</div>;
                                }
                            })()}
                        </div>
                    </div>
                </div>
            )}
        </div >
    );
};

export default Financial;