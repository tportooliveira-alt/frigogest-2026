import { createClient } from '@supabase/supabase-js';

const getEnv = (key: string): string | undefined => {
  // Vite replaces import.meta.env at build time; process.env is available in some environments
  if (typeof process !== 'undefined' && (process.env as any)[key]) {
    return (process.env as any)[key];
  }
  if (typeof import.meta !== 'undefined' && (import.meta as any)?.env?.[key]) {
    return (import.meta as any).env[key];
  }
  return undefined;
};

const SUPABASE_URL = getEnv('VITE_SUPABASE_URL') || getEnv('NEXT_PUBLIC_SUPABASE_URL') || 'https://botapkxwzctrwsnshoyx.supabase.co';
const SUPABASE_ANON_KEY = getEnv('VITE_SUPABASE_ANON_KEY') || getEnv('NEXT_PUBLIC_SUPABASE_ANON_KEY');

if (!SUPABASE_ANON_KEY) {
  // Do not attempt to read supabase.supabaseKey anywhere; rely on envs.
  // In build you may want to fail loudly or allow a dummy key but prefer to fail.
  console.warn('Supabase anon key not found. Set VITE_SUPABASE_ANON_KEY or NEXT_PUBLIC_SUPABASE_ANON_KEY.');
}

export const supabase = createClient(
  SUPABASE_URL,
  SUPABASE_ANON_KEY ?? '',
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      // storage only available in browser
      storage: typeof window !== 'undefined' ? window.localStorage : undefined,
    },
  }
);

export default supabase;